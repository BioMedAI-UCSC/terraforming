"""Planet-specific celestial models."""

