"""Column radiative physics as an explicit forcing on the 3-D primitive equations.

This is the bridge from the 0-D terraforming ODE to the 3-D dycore: it takes the
diurnal/seasonal radiative energy balance that :mod:`src.celestials.planets.mars.seasonal`
integrates for a *single* global-mean column and evaluates it **per grid column**,
then adds the result as a temperature tendency onto dinosaur's dry
``PrimitiveEquationsSigma``. The dry maps path (:mod:`src.celestials.planets.mars.maps`) is
dynamics-only — dinosaur computes every tendency and nothing heats the fluid; here
we supply the missing radiative forcing so the model develops its *own* temperature
structure (hot subsolar point, cold poles/nightside) instead of relaxing a
prescribed rest state. Those horizontal temperature gradients are what drive the
circulation, so this is the step that turns the dry dynamical core into a (grey,
single-band) Mars climate model.

How the coupling works
----------------------
dinosaur's equations are an ``ImplicitExplicitODE`` with a
``explicit_terms(state) -> State`` method. We wrap it: the forced ODE calls the
base ``explicit_terms`` and adds a radiative temperature tendency, leaving the
implicit (gravity-wave) side untouched. The forcing needs the current time for the
diurnal + seasonal cycle — dinosaur's ``State`` already carries a ``sim_time``
field that the base equations advance at unit (nondimensional) rate, so we read it
with no change to the state layout. Initialise the state with ``sim_time=0.0`` (see
:func:`src.celestials.planets.mars.maps.run_maps` with ``forcing=...``) for time to advance.

The nonlinear surface energy balance is evaluated once per column on a prognostic
surface temperature. A conservative bulk sensible flux couples that reservoir to
the lowest atmospheric sigma layer using its mass-dependent heat capacity
``cp*dp/g``. Surface loss and atmospheric gain therefore cancel exactly and the
column budget is independent of vertical layer count.

The legacy grey forcing remains available for regression experiments. The
JCM-style path uses a compact pressure-scaled two-stream solver with CO2 near-IR
and thermal bands plus prescribed dust. It is not yet correlated-k and therefore
must not be described as full LMD/JCM radiative fidelity. Requires the optional
``gcm3d`` extra.
"""

from __future__ import annotations

import dataclasses
import math
from typing import Callable, NamedTuple

import numpy as np

from src.framework.physics import ames_radiation
from src.framework.gcm._dinosaur import (
    jax,
    jnp,
    scales,
    spherical_harmonic,
    time_integration,
)
from src.framework.gcm.body import BodyConstants
from src.framework.gcm.dynamics import primitive_equations as _build_primitive_equations
from src.framework.gcm.dynamics import reference_temperature
from src.framework.gcm.specs import physics_specs

_u = scales.units
_TWO_PI = 2.0 * math.pi
# Layer thicknesses in diurnal skin depths. The deepest layers extend beyond the
# annual skin depth (~sqrt(668.6) diurnal depths) and retain seasonal memory.
_REGOLITH_LAYER_FRACTIONS = (
    0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 12.0, 18.0, 26.0, 38.0, 56.0, 82.0,
)

# Astronomical constants shared with the 0-D orbit model.
TSI_1AU_W_M2 = 1361.0
AU_M = 1.49597870700e11


@dataclasses.dataclass(frozen=True)
class RadiativeForcing:
    """Radiative + orbital constants for the per-column energy-balance forcing.

    Mirrors the subset of :class:`src.celestials.planets.mars.seasonal.SeasonalForcing`
    needed for the temperature tendency (no polar-cap fields — the CO2 cycle is a
    separate increment). Every field is a plain float/bool, so this stays pure
    Python; the values that are *not* on
    :class:`~src.framework.gcm.body.BodyConstants`
    (albedo, greenhouse, emissivity, thermal inertia, orbit) live here.
    """

    # Radiative / thermal
    albedo: object
    greenhouse_factor: float
    emissivity: float
    stefan_boltzmann: float
    thermal_inertia: float
    # Rotation (sets the diurnal hour angle) and obliquity/precession
    rotation_period_s: float
    axial_tilt_rad: float
    ls_perihelion_rad: float
    # Orbit (Keplerian ellipse; angle advances at the mean rate)
    orbital_period_s: float
    semi_major_axis_m: float
    eccentricity: float
    init_orbital_angle_rad: float = 0.0
    # Astronomical constants (overridable for other bodies)
    tsi_1au_w_m2: float = TSI_1AU_W_M2
    au_m: float = AU_M
    # Diurnal cycle on (per-longitude hour angle) or daily-mean insolation.
    diurnal: bool = True
    # Bulk surface-atmosphere sensible heat exchange coefficient (W m-2 K-1).
    # This is deliberately explicit and replaceable: unlike the old layer-uniform
    # heating it transfers energy between two reservoirs without creating energy.
    sensible_heat_transfer_w_m2_k: float = 2.0
    # Neutral bulk aerodynamic surface drag.  The coefficient is diagnosed from
    # the logarithmic surface-layer law at the centre of the lowest sigma layer.
    surface_roughness_m: float = 0.01
    # Auditable scalar for physical-parameter calibration.  It multiplies the
    # diagnosed bulk transfer coefficient, so momentum and sensible-heat
    # exchange stay internally consistent while the spatial roughness map is
    # left unchanged.
    surface_exchange_multiplier: float = 1.0
    von_karman_constant: float = 0.4
    minimum_wind_ms: float = 0.1
    # Regolith properties. Thermal inertia may be replaced by a nodal TES field.
    surface_thermal_inertia_tiu: object = 250.0
    regolith_volumetric_heat_capacity_j_m3_k: float = 1.0e6
    regolith_layer_skin_depth_fractions: tuple[float, ...] = _REGOLITH_LAYER_FRACTIONS
    regolith_enabled: bool = False
    stability_exchange_enabled: bool = False
    pbl_diffusion_enabled: bool = False
    pbl_height_m: float = 5000.0
    pbl_implicit_timestep_s: float = 1800.0
    convective_adjustment_enabled: bool = False
    convective_relaxation_s: float = 900.0
    # Vertically resolved multiband Mars radiation. The two scalar optical depths
    # remain useful experiment controls; the tuples split them into spectral
    # bands with distinct pressure/temperature responses. This is a compact
    # differentiable precursor to Ames-style correlated-k table interpolation,
    # not a replacement for those tables.
    co2_radiation_enabled: bool = False
    # Use the bundled Ames 12-band correlated-k coefficients. Disable only for
    # compact-scheme ablations or installations without the staged asset.
    ames_correlated_k_enabled: bool = True
    # Apply the zenith-angle air-mass factor to direct solar optical paths.
    # Retained as an explicit switch for regression against the legacy vertical-
    # path approximation.
    solar_slant_path_enabled: bool = True
    # Explicit calibration multipliers for the Ames thermal optical depths.
    # Keeping gas and dust separate makes reference-data tuning auditable.
    ames_co2_longwave_opacity_scale: float = 1.0
    ames_dust_longwave_opacity_scale: float = 1.0
    co2_longwave_optical_depth: float = 0.35
    co2_near_ir_optical_depth: float = 0.08
    co2_reference_temperature_k: float = 200.0
    co2_shortwave_band_weights: tuple[float, ...] = (0.72, 0.28)
    co2_shortwave_band_strengths: tuple[float, ...] = (0.35, 2.67)
    co2_shortwave_pressure_exponents: tuple[float, ...] = (1.0, 1.18)
    co2_shortwave_temperature_exponents: tuple[float, ...] = (0.15, 0.55)
    co2_longwave_band_weights: tuple[float, ...] = (0.18, 0.62, 0.20)
    co2_longwave_band_strengths: tuple[float, ...] = (0.12, 1.32, 0.48)
    co2_longwave_pressure_exponents: tuple[float, ...] = (1.0, 1.22, 1.08)
    co2_longwave_temperature_exponents: tuple[float, ...] = (0.10, 0.75, 0.35)
    # Prescribed visible/IR dust column opacity. May be a scalar or nodal field.
    dust_visible_optical_depth: object = 0.0
    dust_longwave_optical_depth: object = 0.0
    # Optional seasonally varying nodal climatology, shaped (season, lon, lat).
    dust_climatology_ls_deg: object | None = None
    dust_visible_climatology: object | None = None
    dust_longwave_climatology: object | None = None
    dust_single_scattering_albedo: float = 0.92
    dust_conrath_parameter: float = 0.003
    dust_top_height_km: object = 35.0
    # Ames mars_surface.F90: albedo_calc, snow_threshold = 2 kg/m2.
    co2_frost_radiative_properties: bool = False
    co2_frost_albedo_north: float = 0.65
    co2_frost_albedo_south: float = 0.43
    co2_frost_emissivity_north: float = 0.81
    co2_frost_emissivity_south: float = 0.88


def surface_radiative_forcing(state, coords, specs, body, forcing):
    """Apply the Ames CO2 snow optical properties above 2 kg/m2 of frost."""
    if not forcing.co2_frost_radiative_properties:
        return forcing
    for name in ("co2_frost_albedo_north", "co2_frost_albedo_south",
                 "co2_frost_emissivity_north", "co2_frost_emissivity_south"):
        value = getattr(forcing, name)
        if not np.isfinite(value) or not 0.0 <= value <= 1.0:
            raise ValueError(f"{name} must be finite and in [0, 1]")
    scale = float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    covered = state.co2_ice[0] > 2.0 * body.gravity_m_s2 / scale
    north = jnp.asarray(coords.horizontal.latitudes)[None, :] > 0.0
    albedo = jnp.where(north, forcing.co2_frost_albedo_north, forcing.co2_frost_albedo_south)
    emissivity = jnp.where(north, forcing.co2_frost_emissivity_north, forcing.co2_frost_emissivity_south)
    return dataclasses.replace(forcing,
        albedo=jnp.where(covered, albedo, forcing.albedo),
        emissivity=jnp.where(covered, emissivity, forcing.emissivity))


# ── Keplerian orbit ───────────────────────────────────────────────────────────
# Epoch convention: ``init_orbital_angle_rad`` is the *mean anomaly* M0 at t=0,
# measured from perihelion (M=0 at perihelion). The mean anomaly advances
# uniformly; the eccentric anomaly E solves Kepler's equation M = E - e sin E;
# the true anomaly nu and heliocentric distance follow from E. Areocentric solar
# longitude is Ls = nu + Ls_perihelion (Ls_perihelion ~= 251 deg for Mars). Use
# :func:`mean_anomaly_for_ls` to set the epoch from a desired Ls consistently.
_KEPLER_ITERS = 6  # Newton iterations; e<0.1 converges to ~machine eps in ~4


def _mean_anomaly(t_s, f: RadiativeForcing):
    """Mean anomaly (rad) at elapsed seconds ``t_s`` — advances uniformly."""
    return f.init_orbital_angle_rad + _TWO_PI * t_s / f.orbital_period_s


def _eccentric_anomaly(mean_anomaly, e: float):
    """Solve Kepler's equation ``M = E - e sin E`` for E (Newton's method)."""
    E = mean_anomaly  # good initial guess for small e
    for _ in range(_KEPLER_ITERS):
        E = E - (E - e * jnp.sin(E) - mean_anomaly) / (1.0 - e * jnp.cos(E))
    return E


def _true_anomaly(t_s, f: RadiativeForcing):
    """True anomaly nu (rad) from the Kepler solution at elapsed seconds ``t_s``."""
    E = _eccentric_anomaly(_mean_anomaly(t_s, f), f.eccentricity)
    e = f.eccentricity
    return 2.0 * jnp.arctan2(
        jnp.sqrt(1.0 + e) * jnp.sin(E / 2.0),
        jnp.sqrt(1.0 - e) * jnp.cos(E / 2.0),
    )


def orbital_distance(t_s, f: RadiativeForcing):
    """Heliocentric distance (m): ``r = a(1 - e cos E)``."""
    E = _eccentric_anomaly(_mean_anomaly(t_s, f), f.eccentricity)
    return f.semi_major_axis_m * (1.0 - f.eccentricity * jnp.cos(E))


def mean_anomaly_for_ls(ls_rad: float, f: RadiativeForcing) -> float:
    """The epoch mean anomaly that places the orbit at solar longitude ``ls_rad``.

    Inverts the Kepler chain (Ls -> nu -> E -> M) so callers can specify a season
    (Ls) rather than a mean anomaly, keeping epoch/perihelion/Ls mutually
    consistent. Returned as a plain float (static epoch config).
    """
    nu = float(ls_rad) - f.ls_perihelion_rad
    e = f.eccentricity
    E = 2.0 * math.atan2(
        math.sqrt(1.0 - e) * math.sin(nu / 2.0),
        math.sqrt(1.0 + e) * math.cos(nu / 2.0),
    )
    return E - e * math.sin(E)


def dust_optical_depths(t_s, f: RadiativeForcing):
    """Return static or periodically interpolated nodal dust column opacities."""
    if f.dust_climatology_ls_deg is None:
        return (
            jnp.asarray(f.dust_visible_optical_depth),
            jnp.asarray(f.dust_longwave_optical_depth),
        )
    if f.dust_visible_climatology is None or f.dust_longwave_climatology is None:
        raise ValueError("seasonal dust requires visible and longwave climatology arrays")
    nodes = jnp.asarray(f.dust_climatology_ls_deg)
    visible = jnp.asarray(f.dust_visible_climatology)
    longwave = jnp.asarray(f.dust_longwave_climatology)
    ls_deg = jnp.mod(
        (_true_anomaly(t_s, f) + f.ls_perihelion_rad) * 180.0 / math.pi,
        360.0,
    )
    right_unwrapped = jnp.searchsorted(nodes, ls_deg, side="right")
    left = jnp.mod(right_unwrapped - 1, nodes.shape[0])
    right = jnp.mod(right_unwrapped, nodes.shape[0])
    left_ls = nodes[left] - jnp.where(right_unwrapped == 0, 360.0, 0.0)
    right_ls = nodes[right] + jnp.where(
        right_unwrapped == nodes.shape[0], 360.0, 0.0
    )
    fraction = (ls_deg - left_ls) / jnp.clip(right_ls - left_ls, 1.0e-12, None)
    return (
        visible[left] + fraction * (visible[right] - visible[left]),
        longwave[left] + fraction * (longwave[right] - longwave[left]),
    )


def solar_flux(t_s, f: RadiativeForcing):
    """Inverse-square solar flux (W m^-2) at elapsed seconds ``t_s``.

    Uses the true Keplerian distance ``r = a(1 - e cos E)`` then
    ``S = S_1AU (AU/r)^2``.
    """
    return f.tsi_1au_w_m2 * (f.au_m / orbital_distance(t_s, f)) ** 2


def _declination(t_s, f: RadiativeForcing):
    """Solar declination (rad): ``arcsin(sin(tilt) sin(Ls))``, Ls = nu + Ls_peri."""
    ls = _true_anomaly(t_s, f) + f.ls_perihelion_rad
    return jnp.arcsin(jnp.sin(f.axial_tilt_rad) * jnp.sin(ls))


def cos_zenith_nodal(t_s, lat_rad, lon_rad, f: RadiativeForcing):
    """Cosine of the solar zenith angle on the ``(n_lon, n_lat)`` nodal grid.

    With ``diurnal`` the hour angle rotates with the planet
    (``h = lon + 2 pi t / rotation_period``), giving a day/night terminator that
    sweeps westward each sol. Without it, the daily-mean insolation factor is used
    (integrated over the hour angle), which is smooth in time and lets the ODE be
    stepped more coarsely. Result is clipped at 0 (no negative insolation) and
    shaped ``(n_lon, n_lat)`` to match dinosaur's nodal fields.
    """
    delta = _declination(t_s, f)
    lat = jnp.asarray(lat_rad)  # (n_lat,)
    sin_lat, cos_lat = jnp.sin(lat), jnp.cos(lat)
    sin_d, cos_d = jnp.sin(delta), jnp.cos(delta)

    if f.diurnal:
        lon = jnp.asarray(lon_rad)  # (n_lon,)
        h = lon[:, None] + (_TWO_PI / f.rotation_period_s) * t_s  # (n_lon,1)
        cz = sin_lat[None, :] * sin_d + cos_lat[None, :] * cos_d * jnp.cos(h)
        return jnp.clip(cz, 0.0, None)

    # Daily-mean insolation factor (mean of clipped cos_zenith over a rotation):
    #   H0 = arccos(-tan(lat) tan(delta));  <cz> = (H0 sinφ sinδ + cosφ cosδ sinH0)/π
    x = jnp.clip(-jnp.tan(lat) * (sin_d / jnp.clip(cos_d, 1e-6, None)), -1.0, 1.0)
    h0 = jnp.arccos(x)  # (n_lat,)
    mean_cz = (h0 * sin_lat * sin_d + cos_lat * cos_d * jnp.sin(h0)) / math.pi
    mean_cz = jnp.clip(mean_cz, 0.0, None)  # (n_lat,)
    n_lon = jnp.asarray(lon_rad).shape[0]
    return jnp.broadcast_to(mean_cz[None, :], (n_lon, mean_cz.shape[0]))


def solar_path_cosine_nodal(t_s, lat_rad, lon_rad, f: RadiativeForcing):
    """Effective cosine for direct-beam optical path length.

    For resolved local time this is the instantaneous positive zenith cosine.
    Daily-mean forcing needs a flux-weighted path cosine rather than its mean
    insolation cosine: ``mu_eff = <mu^2> / <mu>`` over the illuminated part of
    the sol. This preserves the daily-mean incoming energy while accounting for
    the longer atmospheric path at morning, evening, and high latitude.
    """
    if f.diurnal:
        return cos_zenith_nodal(t_s, lat_rad, lon_rad, f)

    delta = _declination(t_s, f)
    lat = jnp.asarray(lat_rad)
    sin_lat, cos_lat = jnp.sin(lat), jnp.cos(lat)
    sin_d, cos_d = jnp.sin(delta), jnp.cos(delta)
    a = sin_lat * sin_d
    b = cos_lat * cos_d
    x = jnp.clip(-jnp.tan(lat) * (sin_d / jnp.clip(cos_d, 1e-6, None)), -1.0, 1.0)
    h0 = jnp.arccos(x)
    mean_mu = jnp.clip((h0 * a + b * jnp.sin(h0)) / math.pi, 0.0, None)
    mean_mu2 = jnp.clip(
        (
            h0 * a**2
            + 2.0 * a * b * jnp.sin(h0)
            + b**2 * (0.5 * h0 + 0.25 * jnp.sin(2.0 * h0))
        )
        / math.pi,
        0.0,
        None,
    )
    effective = jnp.where(mean_mu > 1.0e-12, mean_mu2 / mean_mu, 0.0)
    n_lon = jnp.asarray(lon_rad).shape[0]
    return jnp.broadcast_to(effective[None, :], (n_lon, effective.shape[0]))


class ColumnPhysicsState(NamedTuple):
    """JAX-pytree state for the dycore plus non-advected surface reservoirs.

    Keeping the Dinosaur state intact makes this the stable seam for conventional
    or learned JCM-style column parameterizations. Surface temperature and frost
    are nodal ``(1, n_lon, n_lat)`` fields; frost is pressure-equivalent and may be
    zero when the CO2 cycle is disabled.
    """

    dynamics: object
    surface_temperature: object
    co2_ice: object
    ground_temperature: object
    surface_momentum: object = None


class SurfaceEnergyDiagnostics(NamedTuple):
    absorbed_shortwave_w_m2: object
    outgoing_longwave_w_m2: object
    sensible_heat_w_m2: object
    net_external_w_m2: object


class RadiativeFluxDiagnostics(NamedTuple):
    """Interface fluxes, ordered from TOA (0) to the surface (L)."""

    shortwave_down_w_m2: object
    shortwave_up_w_m2: object
    longwave_up_w_m2: object
    longwave_down_w_m2: object
    atmospheric_convergence_w_m2: object
    surface_net_w_m2: object
    toa_net_down_w_m2: object


def _validate_radiative_bands(f: RadiativeForcing) -> None:
    """Fail early when static spectral configuration has inconsistent lengths."""
    for name in (
        "ames_co2_longwave_opacity_scale",
        "ames_dust_longwave_opacity_scale",
        "surface_exchange_multiplier",
    ):
        value = getattr(f, name)
        # Calibration passes JAX tracers through these fields. Bounds are then
        # enforced by the optimizer's parameter transform; retain eager checks
        # for ordinary user/config values without concretizing a tracer.
        try:
            static_value = float(value)
        except (TypeError, ValueError):
            continue
        if not np.isfinite(static_value) or static_value < 0.0:
            raise ValueError(f"{name} must be finite and non-negative")
    sw_lengths = {
        len(f.co2_shortwave_band_weights),
        len(f.co2_shortwave_band_strengths),
        len(f.co2_shortwave_pressure_exponents),
        len(f.co2_shortwave_temperature_exponents),
    }
    lw_lengths = {
        len(f.co2_longwave_band_weights),
        len(f.co2_longwave_band_strengths),
        len(f.co2_longwave_pressure_exponents),
        len(f.co2_longwave_temperature_exponents),
    }
    if len(sw_lengths) != 1 or 0 in sw_lengths:
        raise ValueError("shortwave CO2 band tuples must have one common non-zero length")
    if len(lw_lengths) != 1 or 0 in lw_lengths:
        raise ValueError("longwave CO2 band tuples must have one common non-zero length")
    if sum(f.co2_shortwave_band_weights) <= 0.0:
        raise ValueError("shortwave CO2 band weights must have a positive sum")
    if sum(f.co2_longwave_band_weights) <= 0.0:
        raise ValueError("longwave CO2 band weights must have a positive sum")


class ColumnPhysicsTendencies(NamedTuple):
    """Replaceable JCM-style physics contribution to the prognostic tendencies."""

    vorticity: object
    divergence: object
    temperature_variation: object
    log_surface_pressure: object
    surface_temperature: object
    co2_ice: object
    ground_temperature: object
    tracers: object
    surface_momentum: object = None


def column_primitive_equations(base, parameterization):
    """Compose Dinosaur dynamics with a conventional or learned column-physics callable.

    ``parameterization(state)`` returns :class:`ColumnPhysicsTendencies`. This is
    the stable integration seam intended for later JCM-inspired deterministic
    packages and NeuralGCM-style learned residual tendencies.
    """
    def explicit_terms(state):
        dry = base.explicit_terms(state.dynamics)
        phy = parameterization(state)
        dynamics = dataclasses.replace(
            dry,
            vorticity=dry.vorticity + phy.vorticity,
            divergence=dry.divergence + phy.divergence,
            temperature_variation=(dry.temperature_variation
                                   + phy.temperature_variation),
            log_surface_pressure=(dry.log_surface_pressure
                                  + phy.log_surface_pressure),
            tracers={
                name: value + phy.tracers.get(name, 0.0)
                for name, value in dry.tracers.items()
            },
        )
        return ColumnPhysicsState(
            dynamics, phy.surface_temperature, phy.co2_ice, phy.ground_temperature,
            (None if state.surface_momentum is None else
             jnp.zeros_like(state.surface_momentum) if phy.surface_momentum is None else phy.surface_momentum),
        )

    def implicit_terms(state):
        return ColumnPhysicsState(
            base.implicit_terms(state.dynamics),
            jnp.zeros_like(state.surface_temperature),
            jnp.zeros_like(state.co2_ice),
            jnp.zeros_like(state.ground_temperature),
            None if state.surface_momentum is None else jnp.zeros_like(state.surface_momentum),
        )

    def implicit_inverse(state, step_size):
        return ColumnPhysicsState(
            base.implicit_inverse(state.dynamics, step_size),
            state.surface_temperature,
            state.co2_ice,
            state.ground_temperature,
            state.surface_momentum,
        )

    return time_integration.ImplicitExplicitODE.from_functions(
        explicit_terms, implicit_terms, implicit_inverse
    )


def compose_column_parameterizations(*parameterizations):
    """Add optional column-physics callables while preserving reservoir fields.

    Each callable receives the same :class:`ColumnPhysicsState` and returns
    :class:`ColumnPhysicsTendencies`. This is the public seam for bounded neural
    residuals: conventional physics remains the first contribution and learned
    tendencies are explicit additions.
    """
    active = tuple(p for p in parameterizations if p is not None)
    if not active:
        return None

    def combined(state):
        values = [p(state) for p in active]
        first = values[0]
        return ColumnPhysicsTendencies(
            *(sum((getattr(v, name) for v in values), jnp.zeros_like(getattr(first, name)))
              for name in ("vorticity", "divergence", "temperature_variation",
                           "log_surface_pressure", "surface_temperature", "co2_ice",
                           "ground_temperature")),
            {name: sum((v.tracers.get(name, 0.0) for v in values), 0.0)
             for name in first.tracers},
            (None if state.surface_momentum is None else
             sum((v.surface_momentum for v in values if v.surface_momentum is not None),
                 jnp.zeros_like(state.surface_momentum))),
        )
    return combined


def initial_column_state(dyn_state, coords, surface_temperature_k: float, specs,
                         ice_pa: float = 0.0,
                         forcing: RadiativeForcing | None = None) -> ColumnPhysicsState:
    """Attach surface/frost/soil reservoirs using the forcing's soil layout.

    Passing the same forcing used by the equation makes a custom regolith layer
    tuple define both state size and conduction geometry. With no forcing, the
    canonical 12-layer layout is used for backwards compatibility.
    """
    ts_nd = float(specs.nondimensionalize(surface_temperature_k * _u.kelvin))
    ice_nd = float(specs.nondimensionalize(ice_pa * _u.pascal))
    shape = coords.surface_nodal_shape
    layer_fractions = tuple(
        _REGOLITH_LAYER_FRACTIONS if forcing is None
        else forcing.regolith_layer_skin_depth_fractions
    )
    if not layer_fractions or any(
        not np.isfinite(x) or x <= 0 for x in layer_fractions
    ):
        raise ValueError("regolith layer skin-depth fractions must be finite and positive")
    ground = jnp.full((len(layer_fractions),) + shape[1:], ts_nd)
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER
    dyn_state = dataclasses.replace(dyn_state, tracers={
        CO2_CLOUD_TRACER: jnp.zeros_like(dyn_state.temperature_variation), **dyn_state.tracers})
    return ColumnPhysicsState(
        dyn_state, jnp.full(shape, ts_nd), jnp.full(shape, ice_nd), ground,
        jnp.zeros((2,) + shape[1:]),
    )


def two_stream_radiative_fluxes(
    state: ColumnPhysicsState, coords, specs, body: BodyConstants,
    f: RadiativeForcing, *, air_temperature_k=None, surface_pressure_pa=None,
) -> RadiativeFluxDiagnostics:
    """Multiband pressure/temperature-scaled CO2/dust radiative fluxes.

    The compact solver uses Beer--Lambert transmission in two solar bands and a
    hemispheric two-stream solve in three thermal bands. Each band responds
    differently to local pressure and temperature. Thermal emission is divided
    by normalized Planck-like band weights and emitted equally upward/downward
    according to Kirchhoff's law. Its principal contract is exact discrete energy
    closure; Ames-style correlated-k coefficients can later replace the optical
    depth closure without changing callers.
    """
    f = surface_radiative_forcing(state, coords, specs, body, f)
    _validate_radiative_bands(f)
    grid, dyn = coords.horizontal, state.dynamics
    n = coords.vertical.layers
    time_scale_s = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
    t_s = dyn.sim_time * time_scale_s
    cz = cos_zenith_nodal(t_s, grid.latitudes, grid.longitudes, f)
    incoming = solar_flux(t_s, f) * cz
    # Convert vertical optical depth to the direct-beam slant path. A small
    # lower bound is immaterial in darkness (incoming is zero) and prevents
    # singular paths at the terminator.
    solar_path_factor = (
        1.0 / jnp.clip(
            solar_path_cosine_nodal(t_s, grid.latitudes, grid.longitudes, f),
            0.05,
            1.0,
        )
        if f.solar_slant_path_enabled else jnp.ones_like(cz)
    )
    dust_visible, dust_longwave = dust_optical_depths(t_s, f)
    if surface_pressure_pa is None:
        ps_nd = jnp.exp(grid.to_nodal(dyn.log_surface_pressure))[0]
        ps_pa = ps_nd * float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    else:
        ps_pa = surface_pressure_pa
    ref = np.asarray(reference_temperature(coords, body)).reshape(n, 1, 1)
    air_k = jnp.clip(
        grid.to_nodal(dyn.temperature_variation) + ref
        if air_temperature_k is None else air_temperature_k,
        1.0, None,
    )
    surface_k = jnp.clip(state.surface_temperature[0], 1.0, None)

    return column_radiative_fluxes(
        air_k, surface_k, ps_pa, incoming, solar_path_factor,
        dust_visible, dust_longwave, coords.vertical.boundaries, body, f,
    )


def column_radiative_fluxes(
    air_k, surface_k, ps_pa, incoming, solar_path_factor,
    dust_visible, dust_longwave, sigma_boundaries, body, f,
) -> RadiativeFluxDiagnostics:
    """Pure array radiation kernel shared by column experiments and the GCM.

    Temperatures are kelvin, pressure Pa, incoming solar W/m²; air has shape
    (layer, column_x, column_y), surface fields broadcast to (column_x, column_y).
    Sigma boundaries are static, ordered from top to surface. Optical depths and
    path factors are dimensionless. No state conversion or file I/O occurs here.
    """
    _validate_radiative_bands(f)
    air_k = jnp.asarray(air_k)
    if air_k.ndim != 3:
        raise ValueError("air temperature must have shape (layer, column_x, column_y)")
    ps_pa = jnp.broadcast_to(jnp.asarray(ps_pa), air_k.shape[1:])
    incoming = jnp.broadcast_to(jnp.asarray(incoming), air_k.shape[1:])
    solar_path_factor = jnp.broadcast_to(jnp.asarray(solar_path_factor), air_k.shape[1:])
    dust_visible, dust_longwave = jnp.asarray(dust_visible), jnp.asarray(dust_longwave)
    surface_k = jnp.broadcast_to(jnp.asarray(surface_k), air_k.shape[1:])
    n = air_k.shape[0]
    if len(sigma_boundaries) != n + 1:
        raise ValueError("sigma boundaries do not match the atmospheric layers")
    boundaries = np.asarray(sigma_boundaries)
    if boundaries[0] != 0 or boundaries[-1] != 1 or not np.all(np.diff(boundaries) > 0):
        raise ValueError("sigma boundaries must increase from 0 to 1")
    air_k = jnp.clip(air_k, 1.0, None)
    surface_k = jnp.clip(surface_k, 1.0, None)
    dsigma = jnp.asarray(np.diff(np.asarray(sigma_boundaries)))[:, None, None]

    sigma_mid = jnp.asarray(
        0.5 * (np.asarray(sigma_boundaries[:-1])
               + np.asarray(sigma_boundaries[1:]))
    )[:, None, None]
    local_pressure_ratio = jnp.clip(
        sigma_mid * ps_pa[None] / body.reference_surface_pressure_pa, 1.0e-6, None
    )
    column_pressure_ratio = ps_pa / body.reference_surface_pressure_pa
    temperature_ratio = jnp.clip(
        f.co2_reference_temperature_k / air_k, 0.25, 4.0
    )
    # Ames new-Conrath profile: mixing ratio falls rapidly above a prescribed
    # dust-top height. Normalize pressure-mass weights so layer optical depths
    # integrate exactly to the requested column opacity.
    zmax = jnp.clip(jnp.asarray(f.dust_top_height_km), 10.0, 60.0)
    conrath_shape = jnp.exp(
        f.dust_conrath_parameter
        * (1.0 - jnp.clip(sigma_mid, 1.0e-4, None) ** (-70.0 / zmax[None]))
    )
    dust_layer_fraction = conrath_shape * dsigma
    dust_layer_fraction /= jnp.sum(dust_layer_fraction, axis=0, keepdims=True)

    def band_tau(base_tau, strengths, p_exponents, t_exponents, dust_tau=0.0):
        """Return ``(band, layer, lon, lat)`` optical depths."""
        values = []
        for strength, p_exp, t_exp in zip(strengths, p_exponents, t_exponents):
            gas = (
                base_tau * strength * column_pressure_ratio[None] * dsigma
                * local_pressure_ratio ** (p_exp - 1.0)
                * temperature_ratio ** t_exp
            )
            values.append(gas + jnp.asarray(dust_tau))
        return jnp.stack(values)

    blackbody_air = f.stefan_boltzmann * air_k**4
    surface_emission = f.emissivity * f.stefan_boltzmann * surface_k**4
    if f.ames_correlated_k_enabled:
        pressure_mid_pa = sigma_mid * ps_pa[None]
        delta_pressure_pa = dsigma * ps_pa[None]
        sw_tau, lw_tau = ames_radiation.correlated_k_optical_depths(
            air_k, pressure_mid_pa, delta_pressure_pa
        )
        lw_tau = lw_tau * f.ames_co2_longwave_opacity_scale
        data = ames_radiation.load_ames_co2_tables_jax()
        sw_channel_weights = ames_radiation.channel_weights(
            data["clear_fraction_sw"]
        )
        lw_channel_weights = ames_radiation.channel_weights(
            data["clear_fraction_ir"]
        )
        # Fixed-size Ames/Wolff dust optics are spectral by gas-table band and
        # applied consistently to every correlated-k channel in that band.
        reference_extinction = ames_radiation.DUST_SW_EXTINCTION[5]
        dust_column = dust_visible * column_pressure_ratio
        dust_ext_sw = (
            dust_column[None, None, None] * dust_layer_fraction[None, None]
            * ames_radiation.DUST_SW_EXTINCTION[:, None, None, None, None]
            / reference_extinction
        )
        dust_ssa_sw = (
            ames_radiation.DUST_SW_SCATTERING / ames_radiation.DUST_SW_EXTINCTION
        )[:, None, None, None, None]
        dust_g_sw = ames_radiation.DUST_SW_ASYMMETRY[:, None, None, None, None]
        total_sw_tau = sw_tau + dust_ext_sw
        omega_sw = dust_ext_sw * dust_ssa_sw / jnp.clip(total_sw_tau, 1.0e-30, None)
        g_sw = jnp.where(dust_ext_sw > 0.0, dust_g_sw, 0.0)
        # Energy-conserving hemispheric two-stream layer coefficients. Forward
        # and backward scattered fractions plus true absorption sum to unity.
        attenuation = jnp.exp(-jnp.clip(
            jnp.sqrt(3.0 * (1.0 - omega_sw) * (1.0 - omega_sw * g_sw))
            * total_sw_tau * solar_path_factor[None, None, None], 0.0, 50.0
        ))
        layer_reflect = 0.5 * omega_sw * (1.0 - g_sw) * (1.0 - attenuation)
        layer_transmit = attenuation + 0.5 * omega_sw * (1.0 + g_sw) * (1.0 - attenuation)

        # The prescribed IR opacity is a separate Ames field; do not infer it
        # from visible opacity. Normalize the five spectral extinction values to
        # the 9-micron-like reference interval used by the column product.
        reference_ir_extinction = ames_radiation.DUST_IR_EXTINCTION[3]
        dust_ir_column = dust_longwave * column_pressure_ratio
        dust_ext_ir = (
            dust_ir_column[None, None, None] * dust_layer_fraction[None, None]
            * ames_radiation.DUST_IR_EXTINCTION[:, None, None, None, None]
            / reference_ir_extinction
        )
        dust_abs_ir = dust_ext_ir * (1.0 - (
            ames_radiation.DUST_IR_SCATTERING / ames_radiation.DUST_IR_EXTINCTION
        )[:, None, None, None, None])
        lw_tau = lw_tau + dust_abs_ir * f.ames_dust_longwave_opacity_scale
        lw_trans = jnp.exp(-jnp.clip(lw_tau / 0.5, 0.0, 50.0))
        solar_weights = data["solar_weights"]
        flux_toa = (incoming[None, None] * solar_weights[:, None, None, None]
                    * sw_channel_weights[:, :, None, None])
        surface_albedo = jnp.asarray(f.albedo)[None, None]
        reflect_levels = jnp.moveaxis(layer_reflect, 2, 0)
        transmit_levels = jnp.moveaxis(layer_transmit, 2, 0)
        surface_albedo = jnp.broadcast_to(surface_albedo, reflect_levels.shape[1:])

        def add_layer(effective_below, layer):
            reflect, transmit = layer
            saved_below = effective_below
            denominator = jnp.clip(1.0 - reflect * effective_below, 1e-8, None)
            effective = reflect + transmit**2 * effective_below / denominator
            return effective, saved_below

        effective_at_toa, below_reversed = jax.lax.scan(
            add_layer, surface_albedo,
            (reflect_levels[::-1], transmit_levels[::-1]),
        )
        below_levels = below_reversed[::-1]

        def propagate_solar(down, layer):
            reflect, transmit, below = layer
            denominator = jnp.clip(1.0 - reflect * below, 1e-8, None)
            next_down = transmit * down / denominator
            return next_down, (next_down, below * next_down)

        _, (down_tail, up_tail) = jax.lax.scan(
            propagate_solar, flux_toa,
            (reflect_levels, transmit_levels, below_levels),
        )
        down_levels = jnp.concatenate([flux_toa[None], down_tail], axis=0)
        up_levels = jnp.concatenate([
            (effective_at_toa * flux_toa)[None], up_tail,
        ], axis=0)
        sw = jnp.sum(down_levels, axis=(1, 2))
        sw_up = jnp.sum(up_levels, axis=(1, 2))

        planck_air = ames_radiation.planck_band_fractions(air_k)
        planck_surface = ames_radiation.planck_band_fractions(surface_k)
        channel = lw_channel_weights[:, :, None, None]
        thermal_emission = (
            blackbody_air[None, None] * planck_air[:, None] * channel[:, :, None]
        )
        thermal_emission = jnp.moveaxis(thermal_emission, 2, 0)
        lw_trans_levels = jnp.moveaxis(lw_trans, 2, 0)

        def propagate_thermal(flux, layer):
            transmission, emission = layer
            next_flux = flux * transmission + (1.0 - transmission) * emission
            return next_flux, next_flux

        zero_flux = jnp.zeros_like(surface_emission[None, None] * planck_surface[:, None] * channel)
        _, down_tail = jax.lax.scan(
            propagate_thermal, zero_flux, (lw_trans_levels, thermal_emission)
        )
        down_levels = jnp.concatenate([zero_flux[None], down_tail], axis=0)
        # Kirchhoff boundary: unabsorbed downward IR returns to the atmosphere.
        surface_flux = (surface_emission[None, None] * planck_surface[:, None] * channel
                        + (1.0 - f.emissivity) * down_tail[-1])
        _, up_reversed = jax.lax.scan(
            propagate_thermal, surface_flux,
            (lw_trans_levels[::-1], thermal_emission[::-1]),
        )
        up_levels = jnp.concatenate([up_reversed[::-1], surface_flux[None]], axis=0)
        lw_up = jnp.sum(up_levels, axis=(1, 2))
        lw_down = jnp.sum(down_levels, axis=(1, 2))
    else:
        # Compact multiband fallback used for ablations.
        sw_tau = band_tau(
            f.co2_near_ir_optical_depth,
            f.co2_shortwave_band_strengths,
            f.co2_shortwave_pressure_exponents,
            f.co2_shortwave_temperature_exponents,
            dust_visible
            * (1.0 - f.dust_single_scattering_albedo)
            * column_pressure_ratio * dust_layer_fraction,
        )
        lw_tau = band_tau(
            f.co2_longwave_optical_depth,
            f.co2_longwave_band_strengths,
            f.co2_longwave_pressure_exponents,
            f.co2_longwave_temperature_exponents,
            dust_longwave * column_pressure_ratio
            * dust_layer_fraction,
        )
        sw_trans = jnp.exp(-jnp.clip(
            sw_tau * solar_path_factor[None, None], 0.0, 50.0
        ))
        lw_trans = jnp.exp(-jnp.clip(lw_tau, 0.0, 50.0))
        sw_weights = jnp.asarray(f.co2_shortwave_band_weights)
        sw_weights = sw_weights / jnp.sum(sw_weights)
        sw_bands = []
        for band in range(len(f.co2_shortwave_band_weights)):
            flux = [incoming * sw_weights[band]]
            for k in range(n):
                flux.append(flux[-1] * sw_trans[band, k])
            sw_bands.append(jnp.stack(flux))
        sw = jnp.sum(jnp.stack(sw_bands), axis=0)
        lw_weights = jnp.asarray(f.co2_longwave_band_weights)
        lw_weights = lw_weights / jnp.sum(lw_weights)
        up_bands, down_bands = [], []
        for band in range(len(f.co2_longwave_band_weights)):
            down = [jnp.zeros_like(surface_k)]
            for k in range(n):
                emission = blackbody_air[k] * lw_weights[band]
                down.append(down[-1] * lw_trans[band, k]
                            + (1.0 - lw_trans[band, k]) * emission)
            down_bands.append(jnp.stack(down))
            up = [surface_emission * lw_weights[band] + (1.0 - f.emissivity) * down[-1]]
            for k in range(n - 1, -1, -1):
                emission = blackbody_air[k] * lw_weights[band]
                up.append(up[-1] * lw_trans[band, k]
                          + (1.0 - lw_trans[band, k]) * emission)
            up_bands.append(jnp.stack(up[::-1]))
        lw_up = jnp.sum(jnp.stack(up_bands), axis=0)
        lw_down = jnp.sum(jnp.stack(down_bands), axis=0)
        sw_up = jnp.zeros_like(sw).at[-1].set(jnp.asarray(f.albedo) * sw[-1])

    return radiative_flux_diagnostics(sw, sw_up, lw_up, lw_down)


def radiative_flux_diagnostics(sw, sw_up, lw_up, lw_down):
    """Derive conservative energy exchanges from interface fluxes in W/m².

    The leading axis runs from top of atmosphere to surface. Directional flux
    magnitudes use positive values. Sum of atmospheric convergence plus surface
    input equals top-of-atmosphere net input, including any imposed downward IR.
    """
    if not (sw.shape == sw_up.shape == lw_up.shape == lw_down.shape):
        raise ValueError("directional flux shapes must match")
    if sw.shape[0] < 2:
        raise ValueError("at least two layer interfaces are required")
    net_up = lw_up + sw_up - lw_down - sw
    convergence = net_up[1:] - net_up[:-1]
    surface_net = -net_up[-1]
    toa_net_down = -net_up[0]
    return RadiativeFluxDiagnostics(
        sw, sw_up, lw_up, lw_down, convergence, surface_net, toa_net_down
    )


def surface_energy_tendencies(state: ColumnPhysicsState, coords, specs,
                              body: BodyConstants, f: RadiativeForcing,
                              wind_nodal=None, temperature_nodal=None, ps_pa=None,
                              *, radiation_component=None):
    """Conservative surface/atmosphere energy exchange.

    Solar and longwave fluxes act once on a prognostic surface reservoir. A bulk
    sensible flux transfers energy to the lowest atmospheric sigma layer, divided
    by its actual areal heat capacity ``cp * dp/g``. Thus the surface loss and
    atmospheric gain cancel exactly and do not depend on the number of layers.
    An optional radiation_component implements the two_stream_radiative_fluxes
    call signature and replaces that call, including both surface and atmospheric
    energy contributions. It requires co2_radiation_enabled=True.
    """
    f = surface_radiative_forcing(state, coords, specs, body, f)
    grid = coords.horizontal
    n_layers = coords.vertical.layers
    dyn = state.dynamics
    if ps_pa is None:
        ps_nd = jnp.exp(grid.to_nodal(dyn.log_surface_pressure))[0]
        pa_per_nd = float(specs.dimensionalize(1.0, _u.pascal).magnitude)
        ps_pa = ps_nd * pa_per_nd

    # sim_time is nondimensional; convert to seconds (time scale = 1/(2 Omega)).
    time_scale_s = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
    t_s = dyn.sim_time * time_scale_s

    cz = cos_zenith_nodal(t_s, grid.latitudes, grid.longitudes, f)  # (n_lon,n_lat)
    # Lowest atmospheric-layer and surface temperatures in kelvin.
    ref_t = np.asarray(reference_temperature(coords, body)).reshape(n_layers, 1, 1)
    air_k = jnp.clip(
        grid.to_nodal(dyn.temperature_variation) + ref_t
        if temperature_nodal is None else temperature_nodal + ref_t,
        1.0, None,
    )
    surface_k = jnp.clip(state.surface_temperature[0], 1.0, None)
    if radiation_component is not None and not f.co2_radiation_enabled:
        raise ValueError("radiation_component requires co2_radiation_enabled=True")
    if f.co2_radiation_enabled:
        radiation_fn = (two_stream_radiative_fluxes if radiation_component is None
                        else radiation_component)
        radiation = radiation_fn(
            state, coords, specs, body, f,
            air_temperature_k=air_k, surface_pressure_pa=ps_pa,
        )
        q_in = (radiation.shortwave_down_w_m2[-1]
                - radiation.shortwave_up_w_m2[-1])
        q_out = radiation.longwave_up_w_m2[-1] - radiation.longwave_down_w_m2[-1]
    else:
        q_in = (1.0 - f.albedo) * solar_flux(t_s, f) * cz
        q_out = f.emissivity * f.stefan_boltzmann * (
            surface_k / max(f.greenhouse_factor, 1.0)
        ) ** 4
    if f.stability_exchange_enabled:
        exchange, _, _ = _surface_exchange_properties(
            state, coords, specs, body, f, air_k[-1], surface_k, ps_pa=None,
            wind_nodal=wind_nodal,
        )
        sensible = exchange * (surface_k - air_k[-1])
    else:
        sensible = f.sensible_heat_transfer_w_m2_k * (surface_k - air_k[-1])

    # Surface reservoir: external radiation minus energy transferred to atmosphere.
    dts_si = (q_in - q_out - sensible) / f.thermal_inertia

    # Lowest-layer areal heat capacity cp*dp/g. In sigma coordinates
    # dp = p_s * delta_sigma, so thickening the atmosphere correctly increases its
    # thermal inertia. No flux is duplicated in the other layers.
    dsigma = float(np.diff(np.asarray(coords.vertical.boundaries))[-1])
    cp = body.gas_constant_j_kg_k / body.kappa
    lowest_capacity = cp * jnp.clip(ps_pa * dsigma / body.gravity_m_s2, 1e-6, None)
    dtair_si = sensible / lowest_capacity
    atm_nodal = jnp.zeros((n_layers,) + sensible.shape).at[-1].set(
        dtair_si * time_scale_s
    )
    if f.co2_radiation_enabled:
        layer_capacity = (
            body.cp_j_kg_k * ps_pa[None] *
            jnp.asarray(np.diff(np.asarray(coords.vertical.boundaries)))[:, None, None]
            / body.gravity_m_s2
        )
        atm_nodal = atm_nodal + radiation.atmospheric_convergence_w_m2 / jnp.clip(
            layer_capacity, 1e-6, None
        ) * time_scale_s
    surface_nd = (dts_si * time_scale_s)[None, :, :]
    diagnostics = SurfaceEnergyDiagnostics(q_in, q_out, sensible, q_in - q_out)
    return grid.to_modal(atm_nodal), surface_nd, diagnostics


def surface_momentum_tendencies(
    state: ColumnPhysicsState, coords, specs, body: BodyConstants, f: RadiativeForcing,
    wind_nodal=None, temperature_nodal=None, ps_pa=None,
):
    """Neutral-log-law surface stress applied to the lowest sigma layer.

    The stress is ``tau = rho C_D |V| V`` and the layer acceleration is
    ``-tau / (dp/g)``.  ``C_D = (kappa/log(z/z0))**2`` uses the hydrostatic
    height of the lowest-layer pressure midpoint.  The tendency always removes
    resolved kinetic energy and approaches zero continuously with wind speed.
    """
    grid, dyn = coords.horizontal, state.dynamics
    if wind_nodal is None:
        wind_nodal = spherical_harmonic.vor_div_to_uv_nodal(
            grid, dyn.vorticity, dyn.divergence
        )
    u_nd, v_nd = wind_nodal
    velocity_unit = _u.meter / _u.second
    u_ms = specs.dimensionalize(u_nd, velocity_unit).magnitude
    v_ms = specs.dimensionalize(v_nd, velocity_unit).magnitude

    ref_t = np.asarray(reference_temperature(coords, body)).reshape(coords.vertical.layers, 1, 1)
    temperature_variation = (
        grid.to_nodal(dyn.temperature_variation)
        if temperature_nodal is None else temperature_nodal
    )
    air_k = jnp.clip(temperature_variation[-1] + ref_t[-1], 50.0, None)
    surface_k = jnp.clip(state.surface_temperature[0], 50.0, None)
    _, drag_coefficient, speed = _surface_exchange_properties(
        state, coords, specs, body, f, air_k, surface_k, ps_pa=ps_pa,
        wind_nodal=wind_nodal,
    )
    dsigma = float(np.diff(np.asarray(coords.vertical.boundaries))[-1])
    # rho/(dp/g) = g/(R*T*dsigma), using the actual lowest-layer temperature.
    rate_s = drag_coefficient * speed * body.gravity_m_s2 / (
        body.gas_constant_j_kg_k * air_k * dsigma
    )
    du_si = jnp.zeros_like(u_ms).at[-1].set(-rate_s * u_ms[-1])
    dv_si = jnp.zeros_like(v_ms).at[-1].set(-rate_s * v_ms[-1])
    acceleration_unit = _u.meter / (_u.second**2)
    du_nd = specs.nondimensionalize(du_si * acceleration_unit)
    dv_nd = specs.nondimensionalize(dv_si * acceleration_unit)
    return spherical_harmonic.uv_nodal_to_vor_div_modal(grid, du_nd, dv_nd)


def _surface_exchange_properties(
    state, coords, specs, body, f, air_k, surface_k, ps_pa=None, wind_nodal=None
):
    """Return sensible conductance, drag coefficient and resolved wind speed."""
    grid = coords.horizontal
    if wind_nodal is None:
        wind_nodal = spherical_harmonic.vor_div_to_uv_nodal(
            grid, state.dynamics.vorticity, state.dynamics.divergence
        )
    u_nd, v_nd = wind_nodal
    unit = _u.meter / _u.second
    u = specs.dimensionalize(u_nd[-1], unit).magnitude
    v = specs.dimensionalize(v_nd[-1], unit).magnitude
    speed = jnp.sqrt(u**2 + v**2 + f.minimum_wind_ms**2)
    sigma = float(np.asarray(coords.vertical.centers)[-1])
    scale_height = body.gas_constant_j_kg_k * body.reference_temperature_k / body.gravity_m_s2
    height = max(-scale_height * math.log(sigma), 1.0)
    roughness = jnp.clip(jnp.asarray(f.surface_roughness_m), 1.0e-5, height / 1.01)
    neutral_cd = (f.von_karman_constant / jnp.log(height / roughness)) ** 2
    if f.stability_exchange_enabled:
        ri = body.gravity_m_s2 * height * (air_k - surface_k) / (
            jnp.clip(air_k, 50.0, None) * speed**2
        )
        ri_width = 5.0e-2
        stable_weight = 0.5 * (1.0 + jnp.tanh(ri / ri_width))
        positive_ri = 0.5 * (ri + jnp.sqrt(ri**2 + ri_width**2))
        negative_ri = 0.5 * (-ri + jnp.sqrt(ri**2 + ri_width**2))
        stable_raw = 1.0 - 5.0 * positive_ri
        stable_floor_width = 1.0e-3
        stable_base = 0.1 + stable_floor_width * jax.nn.softplus(
            (stable_raw - 0.1) / stable_floor_width
        )
        stable = stable_base**2
        unstable = jnp.sqrt(1.0 + 16.0 * negative_ri)
        cd = neutral_cd * (
            stable_weight * stable + (1.0 - stable_weight) * unstable
        )
    else:
        cd = neutral_cd
    cd = cd * jnp.asarray(f.surface_exchange_multiplier)
    if ps_pa is None:
        ps_nd = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0]
        ps_pa = ps_nd * float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    rho = ps_pa / (body.gas_constant_j_kg_k * jnp.clip(air_k, 50.0, None))
    sensible_conductance = rho * body.cp_j_kg_k * cd * speed
    return sensible_conductance, cd, speed


def pbl_vertical_diffusion_tendencies(
    state, coords, specs, body, f, wind_nodal=None, temperature_nodal=None, ps_pa=None
):
    """Mass-conserving adjacent-layer diffusion of momentum and temperature."""
    dyn, grid = state.dynamics, coords.horizontal
    zeros = jnp.zeros_like(dyn.temperature_variation)
    if not f.pbl_diffusion_enabled:
        return (
            jnp.zeros_like(dyn.vorticity), jnp.zeros_like(dyn.divergence), zeros,
            {name: jnp.zeros_like(value) for name, value in dyn.tracers.items()},
        )
    if wind_nodal is None:
        wind_nodal = spherical_harmonic.vor_div_to_uv_nodal(
            grid, dyn.vorticity, dyn.divergence
        )
    u, v = wind_nodal
    temperature = (grid.to_nodal(dyn.temperature_variation)
                   if temperature_nodal is None else temperature_nodal)
    sigma = np.asarray(coords.vertical.centers)
    dsigma = np.diff(np.asarray(coords.vertical.boundaries))
    scale_height = body.gas_constant_j_kg_k * body.reference_temperature_k / body.gravity_m_s2
    z = -scale_height * np.log(np.clip(sigma, 1e-6, None))
    velocity_unit = _u.meter / _u.second
    u_ms = specs.dimensionalize(u, velocity_unit).magnitude
    v_ms = specs.dimensionalize(v, velocity_unit).magnitude
    ref = np.asarray(reference_temperature(coords, body)).reshape(coords.vertical.layers, 1, 1)
    actual_t = temperature + ref
    # Surface-referenced Exner factor: (p / p_surface) ** (R / cp).
    # Dividing actual T by this factor gives potential temperature theta;
    # a dry-neutral column has constant theta, so mixing it adds no heat.
    exner = jnp.asarray(sigma, dtype=actual_t.dtype) ** body.kappa
    theta = actual_t / exner[:, None, None]
    _, cd, speed = _surface_exchange_properties(
        state, coords, specs, body, f,
        actual_t[-1],
        state.surface_temperature[0],
        ps_pa=ps_pa,
        wind_nodal=wind_nodal,
    )
    ustar = jnp.sqrt(cd) * speed
    time_scale = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
    momentum_rates, heat_rates = [], []
    for k in range(coords.vertical.layers - 1):
        interface_z = min(z[k], z[k + 1])
        shape = max(0.0, 1.0 - interface_z / f.pbl_height_m) ** 2
        diffusivity = f.von_karman_constant * ustar * max(interface_z, 1.0) * shape
        dz_local = max(z[k] - z[k + 1], 1.0)
        # A differentiable Richardson-number closure is essential when this
        # operator sits inside a tangent rollout.  The previous hard switch at
        # Ri=0 made otherwise negligible parameter perturbations select
        # different stable/unstable branches in thousands of columns.  Forward
        # AD followed one branch while centered finite differences sampled both,
        # and the discrepancy compounded after only a few physical steps.
        shear2 = (
            ((u_ms[k] - u_ms[k + 1]) / dz_local) ** 2
            + ((v_ms[k] - v_ms[k + 1]) / dz_local) ** 2
            # 0.01 s^-1 corresponds to a 10 m/s change over 1 km.  Below this
            # resolved shear the bulk closure should not infer arbitrarily
            # large Richardson sensitivities from spectral roundoff.
            + 1.0e-4
        )
        ri_gradient = (
            body.gravity_m_s2
            / jnp.clip(0.5 * (theta[k] + theta[k + 1]), 50.0, None)
            * ((theta[k] - theta[k + 1]) / dz_local)
            / shear2
        )
        # A width of 0.05 Richardson number spans the physically uncertain
        # near-neutral regime while remaining narrow relative to the usual
        # turbulent cutoff near Ri=0.25.
        ri_transition_width = 5.0e-2
        stable_weight = 0.5 * (
            1.0 + jnp.tanh(ri_gradient / ri_transition_width)
        )
        positive_ri = 0.5 * (
            ri_gradient
            + jnp.sqrt(ri_gradient**2 + ri_transition_width**2)
        )
        negative_ri = 0.5 * (
            -ri_gradient
            + jnp.sqrt(ri_gradient**2 + ri_transition_width**2)
        )
        stable_factor = 1.0 / (1.0 + 5.0 * positive_ri) ** 2
        unstable_uncapped = jnp.sqrt(1.0 + 16.0 * negative_ri)
        unstable_factor = unstable_uncapped - 1.0e-4 * jax.nn.softplus(
            (unstable_uncapped - 4.0) / 1.0e-4
        )
        stability_factor = (
            stable_weight * stable_factor
            + (1.0 - stable_weight) * unstable_factor
        )
        diffusivity *= stability_factor
        uncapped_rate = diffusivity / dz_local**2
        rate_cap = 1.0 / 1800.0
        rate_width = rate_cap * 1.0e-4
        rate = uncapped_rate - rate_width * jax.nn.softplus(
            (uncapped_rate - rate_cap) / rate_width
        )
        # Stable air transports heat less efficiently than momentum; convective
        # air uses a turbulent Prandtl number near 0.7.
        prandtl = (
            stable_weight * (
                1.0 + 5.0 * (
                    positive_ri - 1.0e-4 * jax.nn.softplus(
                        (positive_ri - 2.0) / 1.0e-4
                    )
                )
            )
            + (1.0 - stable_weight) * 0.7
        )
        momentum_rates.append(rate)
        heat_rates.append(rate / prandtl)
    rates_si = jnp.stack(momentum_rates)
    heat_rates_si = jnp.stack(heat_rates)
    # Mix potential temperature, with enthalpy capacities dsigma * Exner.
    # This leaves a dry-neutral column stationary while conserving sum(dsigma*T).
    # The interface conductance is capacity[k] * rate[k], as in the momentum
    # solve; retain capacities in float64 to avoid a neutral-profile heat leak.
    dtheta, _ = _implicit_vertical_diffusion_tendency(
        theta, heat_rates_si, jnp.asarray(dsigma) * exner,
        f.pbl_implicit_timestep_s, specs
    )
    dt = dtheta * exner[:, None, None]
    du, u_new = _implicit_vertical_diffusion_tendency(
        u_ms, rates_si, dsigma, f.pbl_implicit_timestep_s, specs, velocity=True
    )
    dv, v_new = _implicit_vertical_diffusion_tendency(
        v_ms, rates_si, dsigma, f.pbl_implicit_timestep_s, specs, velocity=True
    )
    # Backward diffusion dissipates resolved kinetic energy. Return that energy
    # uniformly to the mixed air column as heat, preserving the resolved budget.
    old_ke = jnp.sum(jnp.asarray(dsigma)[:, None, None] * (u_ms**2 + v_ms**2) / 2.0, axis=0)
    new_ke = jnp.sum(jnp.asarray(dsigma)[:, None, None] * (u_new**2 + v_new**2) / 2.0, axis=0)
    dissipated_ke = old_ke - new_ke
    smooth_dissipated_ke = 1.0e-8 * jax.nn.softplus(dissipated_ke / 1.0e-8)
    heat_si = smooth_dissipated_ke / (
        body.cp_j_kg_k * jnp.sum(jnp.asarray(dsigma)) * f.pbl_implicit_timestep_s
    )
    dt = dt + heat_si[None] * time_scale
    vor, div = spherical_harmonic.uv_nodal_to_vor_div_modal(grid, du, dv)
    tracer_tendencies = {}
    for name, value in dyn.tracers.items():
        tracer_dt, _ = _implicit_vertical_diffusion_tendency(
            grid.to_nodal(value), heat_rates_si, dsigma,
            f.pbl_implicit_timestep_s, specs,
        )
        tracer_tendencies[name] = grid.to_modal(tracer_dt)
    return vor, div, grid.to_modal(dt), tracer_tendencies


def _implicit_vertical_diffusion_tendency(
    field_si, interface_rate_s, layer_weights, timestep_s, specs, *, velocity=False
):
    """Backward-Euler conservative diffusion using a batched O(L) Thomas solve."""
    n = field_si.shape[0]
    weights = jnp.asarray(layer_weights)
    spatial_shape = field_si.shape[1:]
    lower = jnp.zeros((n,) + spatial_shape)
    diagonal = jnp.ones((n,) + spatial_shape)
    upper = jnp.zeros((n,) + spatial_shape)
    for k in range(n - 1):
        rate = interface_rate_s[k]
        ratio = weights[k] / weights[k + 1]
        diagonal = diagonal.at[k].add(timestep_s * rate)
        upper = upper.at[k].set(-timestep_s * rate)
        lower = lower.at[k + 1].set(-timestep_s * ratio * rate)
        diagonal = diagonal.at[k + 1].add(timestep_s * ratio * rate)

    c0 = upper[0] / diagonal[0]
    d0 = field_si[0] / diagonal[0]

    def eliminate(carry, row):
        c_prev, d_prev = carry
        lo, diag, up, rhs = row
        pivot = diag - lo * c_prev
        c = up / pivot
        d = (rhs - lo * d_prev) / pivot
        return (c, d), (c, d)

    (_, _), (c_tail, d_tail) = jax.lax.scan(
        eliminate, (c0, d0), (lower[1:], diagonal[1:], upper[1:], field_si[1:])
    )
    c_prime = jnp.concatenate([c0[None], c_tail], axis=0)
    d_prime = jnp.concatenate([d0[None], d_tail], axis=0)

    def substitute(next_value, row):
        c, d = row
        value = d - c * next_value
        return value, value

    _, reversed_solution = jax.lax.scan(
        substitute, d_prime[-1], (c_prime[:-1][::-1], d_prime[:-1][::-1])
    )
    new = jnp.concatenate([reversed_solution[::-1], d_prime[-1:]], axis=0)
    tendency_si = (new - field_si) / timestep_s
    if velocity:
        tendency = specs.nondimensionalize(
            tendency_si * (_u.meter / (_u.second**2))
        )
    else:
        time_scale = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
        tendency = tendency_si * time_scale
    return tendency, new


def dry_convective_adjusted_temperature(state, coords, body, temperature_nodal=None):
    """Conservatively neutralize only adjacent unstable parts of each column.

    Weighted decreasing isotonic regression leaves disconnected stable layers
    untouched and conserves sigma-mass-weighted enthalpy in every mixed block.
    """
    grid = coords.horizontal
    n = coords.vertical.layers
    ref = np.asarray(reference_temperature(coords, body)).reshape(n, 1, 1)
    temperature = (
        grid.to_nodal(state.dynamics.temperature_variation)
        if temperature_nodal is None else temperature_nodal
    ) + ref
    sigma = jnp.asarray(coords.vertical.centers).reshape(n, 1, 1)
    exner = sigma ** body.kappa
    theta = temperature / exner
    weights = np.diff(np.asarray(coords.vertical.boundaries))
    w = jnp.asarray(weights).reshape(n, 1, 1)
    enthalpy_weight = w * exner

    def pava_column(values, level_weights):
        block_values = jnp.zeros_like(values)
        block_weights = jnp.zeros_like(level_weights)
        block_counts = jnp.zeros((n,), dtype=jnp.int32)

        def stack_step(stack_state, _):
            vals, weights_, counts, size, input_index = stack_state
            left = jnp.maximum(size - 2, 0)
            right = jnp.maximum(size - 1, 0)
            violates = (size >= 2) & (vals[left] < vals[right])

            def merge(args):
                vals, weights_, counts, size, input_index = args
                total_weight = weights_[left] + weights_[right]
                mean = (
                    vals[left] * weights_[left] + vals[right] * weights_[right]
                ) / total_weight
                vals = vals.at[left].set(mean).at[right].set(0.0)
                weights_ = weights_.at[left].set(total_weight).at[right].set(0.0)
                counts = counts.at[left].add(counts[right]).at[right].set(0)
                return vals, weights_, counts, size - 1, input_index

            def push_or_finish(args):
                vals, weights_, counts, size, input_index = args

                def push(push_args):
                    vals, weights_, counts, size, input_index = push_args
                    vals = vals.at[size].set(values[input_index])
                    weights_ = weights_.at[size].set(level_weights[input_index])
                    counts = counts.at[size].set(1)
                    return vals, weights_, counts, size + 1, input_index + 1

                return jax.lax.cond(
                    input_index < n, push, lambda push_args: push_args, args
                )

            stack_state = jax.lax.cond(
                violates, merge, push_or_finish, stack_state
            )
            return stack_state, None

        initial = (
            block_values,
            block_weights,
            block_counts,
            jnp.int32(0),
            jnp.int32(0),
        )
        (block_values, _, block_counts, _, _), _ = jax.lax.scan(
            stack_step, initial, None, length=2 * n - 1
        )
        cumulative = jnp.cumsum(block_counts)
        level = jnp.arange(n)
        block_index = jnp.sum(level[:, None] >= cumulative[None, :], axis=1)
        return block_values[block_index]

    flat_theta = theta.reshape((n, -1))
    flat_weights = jnp.broadcast_to(enthalpy_weight, theta.shape).reshape((n, -1))
    theta = jax.vmap(pava_column, in_axes=(1, 1), out_axes=1)(
        flat_theta, flat_weights
    ).reshape(theta.shape)
    adjusted = theta * exner
    return grid.to_modal(adjusted - ref)


def dry_convective_adjustment_tendency(
    state, coords, specs, body, f, temperature_nodal=None
):
    if not f.convective_adjustment_enabled:
        return jnp.zeros_like(state.dynamics.temperature_variation)

    # Apply convection as smooth, conservative heat exchange across unstable
    # interfaces.  Calling the exact PAVA projection here makes its discrete
    # block membership part of every physical timestep: infinitesimal forcing
    # changes can then select different blocks, so a tangent rollout and a
    # centered finite difference follow different maps.  The soft positive
    # part below has the same dry-static-stability trigger but remains smooth
    # through neutral stratification.
    grid = coords.horizontal
    n = coords.vertical.layers
    ref = np.asarray(reference_temperature(coords, body)).reshape(n, 1, 1)
    temperature = (
        grid.to_nodal(state.dynamics.temperature_variation)
        if temperature_nodal is None else temperature_nodal
    ) + ref
    sigma = jnp.asarray(coords.vertical.centers).reshape(n, 1, 1)
    exner = sigma ** body.kappa
    theta = temperature / exner
    layer_weights = jnp.asarray(
        np.diff(np.asarray(coords.vertical.boundaries))
    ).reshape(n, 1, 1)
    enthalpy_weights = layer_weights * exner

    transition_k = 0.1
    violation = transition_k * jax.nn.softplus(
        (theta[1:] - theta[:-1]) / transition_k
    )
    lower_weight = enthalpy_weights[:-1]
    upper_weight = enthalpy_weights[1:]
    # This is the weighted heat transfer that would remove each interface's
    # instability, relaxed over the configured convective timescale.  Adding
    # it below and subtracting it above cancels exactly in the column budget.
    heat_flux = (
        violation
        * lower_weight
        * upper_weight
        / (lower_weight + upper_weight)
        / f.convective_relaxation_s
    )
    theta_tendency = jnp.zeros_like(theta)
    theta_tendency = theta_tendency.at[:-1].add(heat_flux / lower_weight)
    theta_tendency = theta_tendency.at[1:].add(-heat_flux / upper_weight)
    temperature_tendency_si = theta_tendency * exner
    time_scale = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
    return grid.to_modal(temperature_tendency_si) * time_scale


def regolith_conduction_tendencies(
    state: ColumnPhysicsState, specs, f: RadiativeForcing
):
    """Conservative finite-volume conduction through skin-depth-scaled soil layers.

    Positive interface flux points downward. The top flux is removed from the
    prognostic surface reservoir and added to the first soil layer; the bottom
    boundary has zero flux. Thus the area-integrated internal energy tendency is
    zero to roundoff in every column.
    """
    if not f.regolith_enabled:
        return (
            jnp.zeros_like(state.surface_temperature),
            jnp.zeros_like(state.ground_temperature),
        )
    time_scale_s = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
    ts = state.surface_temperature[0]
    tg = state.ground_temperature
    inertia = jnp.asarray(f.surface_thermal_inertia_tiu)
    cv = f.regolith_volumetric_heat_capacity_j_m3_k
    skin_depth = inertia / cv * math.sqrt(f.rotation_period_s / math.pi)
    fractions = jnp.asarray(f.regolith_layer_skin_depth_fractions).reshape((-1, 1, 1))
    if tg.shape[0] != fractions.shape[0]:
        raise ValueError(
            "ground_temperature has "
            f"{tg.shape[0]} layers but forcing configures {fractions.shape[0]}; "
            "initialize the state with initial_column_state(..., forcing=forcing)"
        )
    dz = jnp.clip(fractions * skin_depth, 1.0e-4, None)
    conductivity = inertia**2 / cv

    top_distance = 0.5 * dz[0]
    top_flux = conductivity * (ts - tg[0]) / top_distance
    center_distance = 0.5 * (dz[:-1] + dz[1:])
    internal_flux = conductivity * (tg[:-1] - tg[1:]) / center_distance
    fluxes = jnp.concatenate(
        [top_flux[None], internal_flux, jnp.zeros_like(top_flux)[None]], axis=0
    )
    ground_si = (fluxes[:-1] - fluxes[1:]) / (cv * dz)
    surface_si = -top_flux / f.thermal_inertia
    return surface_si[None] * time_scale_s, ground_si * time_scale_s


def radiative_heating_tendency(state, coords, specs, body: BodyConstants,
                               f: RadiativeForcing):
    """Compatibility accessor for the conservative atmospheric tendency.

    ``state`` must now be :class:`ColumnPhysicsState`; radiation cannot be closed
    without the prognostic surface reservoir.
    """
    if not isinstance(state, ColumnPhysicsState):
        raise TypeError("radiative forcing requires a ColumnPhysicsState")
    return surface_energy_tendencies(state, coords, specs, body, f)[0]


def forced_primitive_equations(
    coords,
    body: BodyConstants,
    forcing: RadiativeForcing,
    specs=None,
    orography=None,
    *,
    radiation_component=None,
    neural_tendency=None,
) -> "time_integration.ImplicitExplicitODE":
    """dinosaur dry dynamics with the radiative energy balance added as forcing.

    Returns an ``ImplicitExplicitODE`` whose implicit side is dinosaur's unchanged
    (the semi-implicit gravity-wave treatment) and whose explicit side is the dry
    dynamical tendency **plus** :func:`radiative_heating_tendency`. Integrate it
    with :func:`src.framework.gcm.dynamics.stepper` /
    :func:`src.framework.gcm.dynamics.integrate` exactly like the
    dry equations; the only requirement is that the state carries ``sim_time`` (set
    it to ``0.0``) so the diurnal/seasonal forcing advances.
    Pass radiation_component to replace the conventional flux calculation with
    a compatible callable (including one with bound trainable JAX parameters).
    Pass neural_tendency to add a bounded learned residual to the conventional
    column tendencies; it is applied after radiation and other physical terms.
    """
    if specs is None:
        specs = physics_specs(body)
    if radiation_component is not None and not forcing.co2_radiation_enabled:
        raise ValueError("radiation_component requires co2_radiation_enabled=True")
    base = _build_primitive_equations(coords, body, specs=specs, orography=orography)

    def parameterization(state):
        grid = coords.horizontal
        wind_nodal = spherical_harmonic.vor_div_to_uv_nodal(
            grid,
            state.dynamics.vorticity,
            state.dynamics.divergence,
        )
        temperature_nodal = grid.to_nodal(state.dynamics.temperature_variation)
        ps_nd = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0]
        ps_pa = ps_nd * float(specs.dimensionalize(1.0, _u.pascal).magnitude)
        heat, surface_tendency, _ = surface_energy_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
            radiation_component=radiation_component,
        )
        drag_vor, drag_div = surface_momentum_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
        )
        mix_vor, mix_div, mix_heat, mix_tracers = pbl_vertical_diffusion_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
        )
        convection = dry_convective_adjustment_tendency(
            state, coords, specs, body, forcing, temperature_nodal=temperature_nodal
        )
        ground_surface, ground = regolith_conduction_tendencies(state, specs, forcing)
        return ColumnPhysicsTendencies(
            drag_vor + mix_vor,
            drag_div + mix_div,
            heat + mix_heat + convection,
            jnp.zeros_like(state.dynamics.log_surface_pressure),
            surface_tendency + ground_surface,
            jnp.zeros_like(state.co2_ice),
            ground,
            mix_tracers,
        )
    extra = compose_column_parameterizations(parameterization, neural_tendency)
    return column_primitive_equations(base, extra)


# ==============================================================================
# CO2 condensation cycle (the second half of the 0-D physics, now spatial).
#
# The 0-D model carries two global polar-cap reservoirs. In 3-D the honest analogue
# is the Leighton-Murray cycle: CO2 condenses out of the atmosphere wherever the
# surface reaches the CO2 frost point (the winter poles), releasing latent heat and
# *removing atmospheric mass* (local surface pressure drops); the deposited frost
# sublimes back when insolation warms it, restoring the mass. This buffers polar
# temperatures near the frost point — the missing physics that let the dry+radiation
# run's winter pole cool to an unphysical ~66 K.
#
# Surface frost sits on the ground, so it is *not* advected by the 3-D wind and must
# not be a dinosaur tracer (those get transported). Instead the state becomes a
# :class:`ColumnPhysicsState` JAX pytree. ``co2_ice`` is stored in pressure-equivalent
# units (the surface pressure the frost would contribute if fully sublimed), so mass
# conservation is exact per cell: ``d(p_s) = -d(ice) - escape``.
# ==============================================================================


@dataclasses.dataclass(frozen=True)
class CO2Forcing:
    """Constants for the 3-D CO2 condensation/sublimation cycle.

    ``frost_point_k`` is treated as fixed (the CO2 saturation temperature varies
    only weakly over Mars's pressure range). ``exchange_rate_pa_s_per_k`` sets how
    fast the surface relaxes toward the frost point via condensation — the free
    parameter of this smooth (differentiable) scheme; the default buffers polar
    temperatures over a few sols without destabilising the explicit step.
    """

    frost_point_k: float               # constant fallback (used if use_pressure_frost=False)
    latent_heat_j_kg: float
    gravity_m_s2: float
    thermal_inertia: float
    # Use the pressure-dependent CO2 saturation temperature (Clausius-Clapeyron
    # curve) instead of the constant frost_point_k. See :func:`co2_frost_point_k`.
    use_pressure_frost: bool = True
    # Smooth condensation/sublimation rate (Pa of exchange per K of frost offset
    # per second) and the ice scale that gates sublimation to zero as frost runs out.
    exchange_rate_pa_s_per_k: float = 1.0e-4
    ice_ref_pa: float = 100.0
    # Condensation supply limit: the rate is gated by tanh(p_s / supply_scale_pa)
    # so it vanishes as the local atmosphere thins. Without this, runaway
    # condensation collapses the polar surface pressure to zero (d(ln p_s) blows
    # up as p_s -> 0) and the integration diverges — you cannot condense CO2 that
    # is no longer in the column.
    supply_scale_pa: float = 50.0
    # Non-thermal escape (uniform atmospheric mass sink), kg s^-1 over the globe.
    escape_rate_kg_s: float = 0.0
    # Diagnose phase change from the non-latent surface energy residual.  This
    # removes the tunable temperature-relaxation rate from the active scheme.
    energy_limited: bool = False
    # Four-stage IMEX evaluations can sample intermediate reservoirs, so use a
    # conservative four-step positivity horizon for the default 600 s step.
    exchange_timestep_s: float = 24000.0
    # Finite-rate condensation aloft; released latent heat stays in the air.
    atmospheric_condensation: bool = True
    atmospheric_condensation_timescale_s: float = 3600.0
    cloud_particle_radius_m: float = 50.e-6
    cloud_ice_density_kg_m3: float = 1600.
    cloud_ice_heat_capacity_j_kg_k: float = 850.


def co2_frost_point_k(pressure_pa):
    """CO2 condensation (frost-point) temperature (K) at partial pressure ``pressure_pa``.

    Uses the CO2 saturation-vapour-pressure (Clausius-Clapeyron) relation in the
    inverted, GCM-standard form

        T_sat = 3182.48 / (23.3494 - ln p[hPa])

    which is the CO2 condensation temperature used in Mars GCMs. It is well
    calibrated against the CO2 phase curve: it returns ~147.7 K at 6.1 hPa (Mars
    surface pressure) and 194.6 K at 1013 hPa (the CO2 sublimation point at 1 atm),
    and rises with pressure as Clausius-Clapeyron requires. ``pressure_pa`` is
    clipped to a small positive floor so the log stays finite in vacuum cells.
    """
    p_hpa = jnp.clip(jnp.asarray(pressure_pa) / 100.0, 1e-6, None)
    return 3182.48 / (23.3494 - jnp.log(p_hpa))


def _co2_surface_tendencies(
    state, coords, specs, body, cf: CO2Forcing,
    available_surface_flux_w_m2=None, surface_pressure_pa=None,
):
    """Per-cell CO2 exchange: returns pressure, frost, and surface-T tendencies.

    Works in SI (Pa s^-1, K s^-1) then nondimensionalises. ``ice_nd`` is the frost
    reservoir in nondimensional pressure-equivalent units (same scaling as p_s).
    Condensation (surface below the frost point) moves mass atmosphere -> ice and
    warms; sublimation (above frost, gated by available ice) moves it back and cools.
    """
    grid = coords.horizontal
    dyn, ice_nd = state.dynamics, state.co2_ice

    # Prognostic physical surface temperature (K) and surface pressure (Pa).
    t_surf_k = jnp.clip(state.surface_temperature[0], 1.0, None)
    pressure_scale_pa = float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    if surface_pressure_pa is None:
        ps_nd = jnp.exp(grid.to_nodal(dyn.log_surface_pressure))
        ps_pa = pressure_scale_pa * ps_nd
    else:
        ps_pa = surface_pressure_pa[None]
        ps_nd = ps_pa / pressure_scale_pa

    # Ice reservoir in Pa (dimensional) for gating and rates.
    ice_pa = specs.dimensionalize(ice_nd, _u.pascal).magnitude        # (1,n_lon,n_lat)

    # Frost point: pressure-dependent CO2 saturation temperature per cell (or the
    # constant fallback). Using the local p_s makes the winter-pole cap form at the
    # right temperature and respond as the atmosphere thickens/thins.
    frost_k = (co2_frost_point_k(ps_pa[0]) if cf.use_pressure_frost
               else cf.frost_point_k)
    supply_gate = jnp.tanh(ps_pa[0] / cf.supply_scale_pa)
    ice_gate = jnp.tanh(
        (1.0e-6 * jax.nn.softplus(ice_pa[0] / 1.0e-6)) / cf.ice_ref_pa
    )
    if cf.energy_limited:
        if available_surface_flux_w_m2 is None:
            raise ValueError("energy-limited CO2 exchange requires the surface-energy residual")
        residual = jnp.asarray(available_surface_flux_w_m2)
        pa_per_watt = cf.gravity_m_s2 / cf.latent_heat_j_kg
        # A finite frost transition represents sub-grid surface-temperature
        # variation and avoids a discrete set of condensing grid cells in a
        # tangent rollout.  The flux softplus likewise removes the kink at a
        # zero surface-energy residual while becoming the ordinary positive
        # part outside a narrow 0.1 W m^-2 interval.
        frost_transition_k = 0.1
        cond_gate = jax.nn.sigmoid(
            (frost_k - t_surf_k) / frost_transition_k
        )
        subl_gate = jax.nn.sigmoid(
            (t_surf_k - frost_k) / frost_transition_k
        )
        flux_transition_w_m2 = 0.1
        cond_energy = flux_transition_w_m2 * jax.nn.softplus(
            -residual / flux_transition_w_m2
        )
        subl_energy = flux_transition_w_m2 * jax.nn.softplus(
            residual / flux_transition_w_m2
        )
        cond_pa_s = cond_gate * cond_energy * pa_per_watt * supply_gate
        subl_pa_s = subl_gate * subl_energy * pa_per_watt * ice_gate
    else:
        below = jnp.clip(frost_k - t_surf_k, 0.0, None)
        above = jnp.clip(t_surf_k - frost_k, 0.0, None)
        cond_pa_s = cf.exchange_rate_pa_s_per_k * below * supply_gate
        subl_pa_s = cf.exchange_rate_pa_s_per_k * above * ice_gate
    # Positivity limiter for the explicit phase-change tendency. The configured
    # interval is the maximum physics step supported by this forcing.
    cond_pa_s = jnp.minimum(cond_pa_s, jnp.clip(ps_pa[0], 0.0, None) / cf.exchange_timestep_s)
    subl_pa_s = jnp.minimum(subl_pa_s, jnp.clip(ice_pa[0], 0.0, None) / cf.exchange_timestep_s)
    net_pa_s = cond_pa_s - subl_pa_s                                   # (n_lon,n_lat), >0 = condensing

    # Positivity repair for intermediate Runge--Kutta stages. It transfers any
    # tiny negative numerical reservoir back from the atmosphere, so total CO2
    # remains unchanged while the physical state is restored rapidly.
    repair_pa_s = jnp.clip(-ice_pa[0], 0.0, None) / 60.0

    # Escape: uniform atmospheric mass sink spread over the globe (Pa s^-1).
    escape_pa_s = cf.escape_rate_kg_s * cf.gravity_m_s2 / body.surface_area_m2

    # Mass budget (SI, per cell): ice gains net, atmosphere loses net + escape.
    dice_pa_s = (net_pa_s + repair_pa_s)[None, :, :]                   # (1,n_lon,n_lat)
    dps_pa_s = (-net_pa_s - repair_pa_s)[None, :, :] - escape_pa_s

    # Latent heating: condensing mass (net/g kg m^-2 s^-1) releases L (W m^-2).
    dT_latent_si = cf.latent_heat_j_kg * (net_pa_s / cf.gravity_m_s2) / cf.thermal_inertia

    # --- nondimensionalise ---
    to_nd_press_rate = lambda x: specs.nondimensionalize(x * (_u.pascal / _u.second))
    time_scale_s = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))

    dice_nd = to_nd_press_rate(dice_pa_s)                              # (1,n_lon,n_lat)
    dps_nd = to_nd_press_rate(dps_pa_s)                               # (1,n_lon,n_lat)
    d_logsp_nodal = dps_nd / ps_nd                                    # d(ln p_s)/dt
    d_logsp_modal = grid.to_modal(d_logsp_nodal)

    # Latent energy belongs to the surface reservoir where frost forms/sublimes.
    dT_latent_nd = (dT_latent_si * time_scale_s)[None, :, :]
    return d_logsp_modal, dice_nd, dT_latent_nd


def _co2_atmospheric_tendencies(state, temperature_nodal, ps_pa, wind_nodal, coords, specs, body, cf):
    """Finite-rate phase change into a transported suspended-ice reservoir."""
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER, phase_exchange
    grid = coords.horizontal
    heat_zero = jnp.zeros_like(state.dynamics.temperature_variation)
    if not cf.atmospheric_condensation:
        return heat_zero, jnp.zeros_like(ps_pa)[None], heat_zero, heat_zero, heat_zero
    if CO2_CLOUD_TRACER not in state.dynamics.tracers:
        raise ValueError("CO2 cloud tracer missing; initialize with initial_column_state or load_restart")
    sigma = np.asarray(coords.vertical.centers, dtype=float)
    dsigma = np.diff(np.asarray(coords.vertical.boundaries, dtype=float))
    temperature = temperature_nodal + jnp.asarray(reference_temperature(coords, body))[:, None, None]
    ice_ratio = grid.to_nodal(state.dynamics.tracers[CO2_CLOUD_TRACER])
    speed_scale = float(specs.dimensionalize(1., _u.meter / _u.second).magnitude)
    wind = jnp.stack(wind_nodal) * speed_scale
    frost = co2_frost_point_k(jnp.asarray(sigma)[:, None, None] * ps_pa[None])
    heat, pressure, ice, momentum = phase_exchange(
        temperature, ps_pa, ice_ratio, wind, frost, sigma, dsigma, body, cf)
    time_scale = 1. / float(specs.nondimensionalize(1. * _u.second))
    vor, div = spherical_harmonic.uv_nodal_to_vor_div_modal(
        grid, momentum[0] * time_scale / speed_scale, momentum[1] * time_scale / speed_scale)
    return (grid.to_modal(heat * time_scale),
            specs.nondimensionalize(pressure[None] * (_u.pascal / _u.second)),
            grid.to_modal(ice * time_scale), vor, div)


def settle_co2_clouds(state, coords, specs, body, cf, dt_seconds):
    """Deposit cloud ice, sensible/kinetic/gravitational energy and momentum."""
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER, settle
    grid = coords.horizontal
    if state.surface_momentum is None:
        raise ValueError("cloud settling requires the surface momentum reservoir")
    sigma = np.asarray(coords.vertical.centers, dtype=float)
    dsigma = np.diff(np.asarray(coords.vertical.boundaries, dtype=float))
    pressure_scale = float(specs.dimensionalize(1., _u.pascal).magnitude)
    speed_scale = float(specs.dimensionalize(1., _u.meter / _u.second).magnitude)
    reference = jnp.asarray(reference_temperature(coords, body))[:, None, None]
    temperature = grid.to_nodal(state.dynamics.temperature_variation) + reference
    pressure = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0] * pressure_scale
    cloud = grid.to_nodal(state.dynamics.tracers[CO2_CLOUD_TRACER])
    wind = jnp.stack(spherical_harmonic.vor_div_to_uv_nodal(
        grid, state.dynamics.vorticity, state.dynamics.divergence)) * speed_scale
    temperature, cloud, wind, deposit, heat, impulse = settle(
        temperature, pressure, cloud, wind, state.surface_temperature[0],
        sigma, dsigma, body, cf, dt_seconds)
    vor, div = spherical_harmonic.uv_nodal_to_vor_div_modal(grid, wind[0] / speed_scale, wind[1] / speed_scale)
    dynamics = dataclasses.replace(state.dynamics, temperature_variation=grid.to_modal(temperature - reference),
        vorticity=vor, divergence=div,
        tracers={**state.dynamics.tracers, CO2_CLOUD_TRACER: grid.to_modal(cloud)})
    frost_mass = state.co2_ice * pressure_scale / body.gravity_m_s2
    capacity = cf.thermal_inertia + (frost_mass[0] + deposit) * cf.cloud_ice_heat_capacity_j_kg_k
    return state._replace(dynamics=dynamics,
        surface_temperature=state.surface_temperature + (heat / capacity)[None],
        co2_ice=state.co2_ice + deposit[None] * body.gravity_m_s2 / pressure_scale,
        surface_momentum=state.surface_momentum + impulse)


def forced_co2_primitive_equations(
    coords,
    body: BodyConstants,
    forcing: RadiativeForcing,
    co2_forcing: CO2Forcing,
    specs=None,
    orography=None,
    *,
    radiation_component=None,
    neural_tendency=None,
) -> "time_integration.ImplicitExplicitODE":
    """Dry dynamics + radiative forcing + CO2 condensation cycle on a tuple state.

    The ODE operates on :class:`ColumnPhysicsState`, carrying the Dinosaur state,
    prognostic surface temperature, and a nodal surface frost reservoir. Build it
    with :func:`initial_column_state` or :func:`initial_co2_state`; integrate with
    the ordinary :func:`src.framework.gcm.dynamics.stepper` /
    :func:`src.framework.gcm.dynamics.integrate`.
    """
    if specs is None:
        specs = physics_specs(body)
    for name in ("atmospheric_condensation_timescale_s", "exchange_timestep_s",
                 "cloud_particle_radius_m", "cloud_ice_density_kg_m3", "cloud_ice_heat_capacity_j_kg_k",
                 "latent_heat_j_kg", "gravity_m_s2", "thermal_inertia"):
        value = getattr(co2_forcing, name)
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive")
    if radiation_component is not None and not forcing.co2_radiation_enabled:
        raise ValueError("radiation_component requires co2_radiation_enabled=True")
    base = _build_primitive_equations(coords, body, specs=specs, orography=orography)

    def parameterization(state):
        grid = coords.horizontal
        wind_nodal = spherical_harmonic.vor_div_to_uv_nodal(
            grid,
            state.dynamics.vorticity,
            state.dynamics.divergence,
        )
        temperature_nodal = grid.to_nodal(state.dynamics.temperature_variation)
        ps_nd = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0]
        ps_pa = ps_nd * float(specs.dimensionalize(1.0, _u.pascal).magnitude)
        heat, dsurface, _ = surface_energy_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
            radiation_component=radiation_component,
        )
        ground_surface, ground = regolith_conduction_tendencies(state, specs, forcing)
        time_scale = 1.0 / float(specs.nondimensionalize(1.0 * _u.second))
        surface_flux = (
            (dsurface + ground_surface)[0] / time_scale * forcing.thermal_inertia
        )
        d_logsp, dice, dlatent_surface = _co2_surface_tendencies(
            state, coords, specs, body, co2_forcing,
            available_surface_flux_w_m2=surface_flux,
            surface_pressure_pa=ps_pa,
        )
        atmospheric_heat, atmospheric_pressure, cloud_ice, cloud_vor, cloud_div = _co2_atmospheric_tendencies(
            state, temperature_nodal, ps_pa, wind_nodal, coords, specs, body, co2_forcing
        )
        from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER
        if co2_forcing.atmospheric_condensation:
            cloud = grid.to_nodal(state.dynamics.tracers[CO2_CLOUD_TRACER])
            cloud_ice = cloud_ice - grid.to_modal(cloud * grid.to_nodal(d_logsp))
        d_logsp = d_logsp + grid.to_modal(atmospheric_pressure / ps_nd[None])
        drag_vor, drag_div = surface_momentum_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
        )
        mix_vor, mix_div, mix_heat, mix_tracers = pbl_vertical_diffusion_tendencies(
            state, coords, specs, body, forcing, wind_nodal=wind_nodal,
            temperature_nodal=temperature_nodal, ps_pa=ps_pa,
        )
        convection = dry_convective_adjustment_tendency(
            state, coords, specs, body, forcing, temperature_nodal=temperature_nodal
        )
        if co2_forcing.atmospheric_condensation:
            mix_tracers = {**mix_tracers, CO2_CLOUD_TRACER: mix_tracers.get(CO2_CLOUD_TRACER, 0.) + cloud_ice}
        return ColumnPhysicsTendencies(
            drag_vor + mix_vor + cloud_vor, drag_div + mix_div + cloud_div,
            heat + mix_heat + convection + atmospheric_heat, d_logsp,
            dsurface + dlatent_surface + ground_surface,
            dice,
            ground,
            mix_tracers,
        )
    extra = compose_column_parameterizations(parameterization, neural_tendency)
    return column_primitive_equations(base, extra)


def cloud_pressure_equivalent(state, coords):
    """Suspended CO2 mass in the same nondimensional pressure units as frost."""
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER
    grid = coords.horizontal
    if CO2_CLOUD_TRACER not in state.dynamics.tracers:
        return jnp.zeros_like(state.co2_ice)
    cloud = grid.to_nodal(state.dynamics.tracers[CO2_CLOUD_TRACER])
    dsigma = jnp.asarray(np.diff(coords.vertical.boundaries), dtype=cloud.dtype)[:, None, None]
    pressure = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))
    return pressure * jnp.sum(cloud * dsigma, axis=0, keepdims=True)


def project_co2_reservoirs(state: ColumnPhysicsState, coords, specs):
    """Project frost to non-negative values while conserving local CO2 mass.

    Explicit multistage schemes do not preserve positivity at a moving frost
    boundary. Any negative pressure-equivalent frost is set to zero and the same
    pressure deficit is removed from the atmospheric column. The correction is
    applied after a complete timestep, not within Runge--Kutta stages.
    """
    grid = coords.horizontal
    pressure_scale = float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    ice_pa = state.co2_ice * pressure_scale
    ps_nd = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))
    ps_pa = ps_nd * pressure_scale
    deficit_pa = jnp.clip(-ice_pa, 0.0, None)
    ice_pa = jnp.clip(ice_pa, 0.0, None)
    ps_pa = jnp.clip(ps_pa - deficit_pa, 1.0e-6, None)
    dynamics = dataclasses.replace(
        state.dynamics,
        log_surface_pressure=jax.lax.cond(jnp.any(deficit_pa > 0.),
            lambda _: grid.to_modal(jnp.log(ps_pa / pressure_scale)),
            lambda _: state.dynamics.log_surface_pressure, operand=None),
    )
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER
    if CO2_CLOUD_TRACER in dynamics.tracers:
        original = dynamics.tracers[CO2_CLOUD_TRACER]
        cloud = grid.to_nodal(original)
        # A gas-carrier change must preserve cloud burden, not mixing ratio.
        cloud = jax.lax.cond(jnp.any(deficit_pa > 0.),
            lambda _: grid.to_modal(cloud * ps_nd / (ps_pa / pressure_scale)),
            lambda _: original, operand=None)
        nodal = grid.to_nodal(cloud)
        weights = jnp.asarray(grid.quadrature_weights) * ps_pa[0]
        mean = jnp.sum(nodal * weights, axis=(-2, -1), keepdims=True) / jnp.sum(weights)
        minimum = jnp.min(nodal, axis=(-2, -1), keepdims=True)
        denominator = jnp.where(minimum < 0., jnp.maximum(mean - minimum, 1.e-12), 1.)
        factor = jnp.where(minimum < 0., jnp.maximum(mean, 0.) / denominator, 1.)
        uniform = grid.to_modal(jnp.ones(coords.surface_nodal_shape))
        cloud = cloud * factor + uniform * (jnp.maximum(mean, 0.) * (1. - factor))
        dynamics = dataclasses.replace(dynamics, tracers={**dynamics.tracers, CO2_CLOUD_TRACER: cloud})
    return state._replace(
        dynamics=dynamics,
        co2_ice=ice_pa / pressure_scale,
    )


class CO2ProjectionDiagnostics(NamedTuple):
    """Global mass accounting for one projected step, in SI units.

    These are numerical-correction diagnostics, not an energy-closure proof.
    ``negative_frost_repair_kg`` is an internal atmosphere-to-frost transfer;
    ``atmospheric_rescale_kg`` is the mass subsequently added/removed by the
    global pressure projection. Neither is a declared physical source.
    """

    raw_total_mass_kg: object
    target_total_mass_kg: object
    corrected_total_mass_kg: object
    external_co2_mass_change_kg: object
    escape_mass_kg: object
    negative_frost_repair_kg: object
    atmospheric_rescale_kg: object
    pressure_factor: object
    valid_inventory: object
    raw_exchange_energy_j: object = None
    frost_repaired_exchange_energy_j: object = None
    settled_exchange_energy_j: object = None
    corrected_exchange_energy_j: object = None
    raw_axial_angular_momentum_kg_m2_s: object = None
    frost_repaired_axial_angular_momentum_kg_m2_s: object = None
    settled_axial_angular_momentum_kg_m2_s: object = None
    corrected_axial_angular_momentum_kg_m2_s: object = None


def co2_exchange_budgets(state, coords, specs, body, cf):
    """SI resolved atmosphere/surface exchange budgets on Gaussian cell areas.

    Energy is gas enthalpy, cloud sensible/latent/potential/kinetic energy,
    gas kinetic energy, and surface/frost heat. Ground conduction/radiation are
    external to this control volume. This is not the dry-core energy theorem.
    Stage differences expose numerical repairs instead of relabelling them as
    physical heat or torque.
    """
    from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER, column_budgets
    grid = coords.horizontal
    scale = float(specs.dimensionalize(1., _u.pascal).magnitude)
    speed = float(specs.dimensionalize(1., _u.meter / _u.second).magnitude)
    pressure = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0] * scale
    reference = jnp.asarray(reference_temperature(coords, body))[:, None, None]
    temperature = grid.to_nodal(state.dynamics.temperature_variation) + reference
    ratio = (grid.to_nodal(state.dynamics.tracers[CO2_CLOUD_TRACER])
             if CO2_CLOUD_TRACER in state.dynamics.tracers else jnp.zeros_like(temperature))
    wind = jnp.stack(spherical_harmonic.vor_div_to_uv_nodal(
        grid, state.dynamics.vorticity, state.dynamics.divergence)) * speed
    mass, energy, momentum = column_budgets(temperature, pressure, ratio, wind,
        np.asarray(coords.vertical.centers, dtype=float),
        np.diff(np.asarray(coords.vertical.boundaries, dtype=float)), body, cf)
    frost = state.co2_ice[0] * scale / body.gravity_m_s2
    energy = energy + cf.thermal_inertia * state.surface_temperature[0] + frost * (
        cf.cloud_ice_heat_capacity_j_kg_k * state.surface_temperature[0] - cf.latent_heat_j_kg)
    ground_zonal = 0. if state.surface_momentum is None else state.surface_momentum[0]
    lever = body.radius_m * jnp.asarray(grid.cos_lat)
    axial = lever * (momentum[0] + ground_zonal + (mass + frost) * body.angular_velocity_s * lever)
    area = jnp.asarray(grid.quadrature_weights)
    area = area / jnp.sum(area) * body.surface_area_m2
    return jnp.sum(energy * area), jnp.sum(axial * area)


def positivity_preserving_co2_step(
    step_fn,
    coords,
    specs,
    *,
    body: BodyConstants | None = None,
    co2_forcing: CO2Forcing | None = None,
    dt_seconds: float | None = None,
    external_co2_mass_change_kg: Callable[[ColumnPhysicsState, float], object] | None = None,
    return_diagnostics: bool = False,
):
    """Wrap an IMEX step with positivity and global CO2-mass projections.

    The phase-change tendency is conservative in pressure coordinates, but the
    dynamical state advances ``log(p_s)``. A finite Runge--Kutta step therefore
    does not preserve ``p_s + p_ice`` exactly even when its instantaneous
    tendency does. The small one-step error accumulates over a Mars year and can
    become a material artificial source of atmospheric mass.

    After repairing negative frost, rescale atmospheric pressure by one global
    factor so the Gaussian-quadrature integral of atmosphere plus surface frost
    matches the inventory before the step plus declared external CO2 sources,
    less configured escape. The rescaling preserves the resolved spatial
    pressure pattern and keeps pressure positive for feasible inventories.

    ``external_co2_mass_change_kg(state_before, dt_seconds)`` returns a scalar
    global CO2 mass change for the entire step (positive source, negative sink),
    excluding ``co2_forcing.escape_rate_kg_s``. The underlying ``step_fn`` must
    apply that source/sink and its thermal/momentum effects; this callback only
    declares the conservation target and must not inject material a second time.
    It must be pure and JAX-compatible; schedule times should be derived from
    the persisted simulation clock, not mutable Python counters. ``sim_time``
    in the dynamics is nondimensional and must be converted with ``specs``.

    This is a CO2-only budget, not a gas-mixture or suspended-aerosol model.
    New species require independent inventories and validated thermodynamics.
    With ``return_diagnostics=True`` each call returns ``(state, diagnostics)``
    instead of just state; callers must explicitly accumulate/check diagnostics.
    Impossible or non-finite inventory targets produce a non-finite pressure
    state (and ``valid_inventory=False``), rather than silently inventing mass.
    """
    grid = coords.horizontal
    weights = jnp.asarray(grid.quadrature_weights)
    pressure_scale = float(specs.dimensionalize(1.0, _u.pascal).magnitude)
    weight_sum = jnp.sum(weights)
    uniform_log_pressure = grid.to_modal(jnp.ones(coords.surface_nodal_shape))

    has_escape = co2_forcing is not None and co2_forcing.escape_rate_kg_s != 0.0
    if has_escape or external_co2_mass_change_kg is not None:
        if body is None or dt_seconds is None:
            raise ValueError("body and dt_seconds are required for external CO2 sources/sinks or escape")
        if not np.isfinite(dt_seconds) or dt_seconds <= 0:
            raise ValueError("dt_seconds must be finite and > 0")
    if return_diagnostics and body is None:
        raise ValueError("body is required for CO2 projection diagnostics in SI units")
    mass_per_integral = (
        body.surface_area_m2 * pressure_scale / (body.gravity_m_s2 * weight_sum)
        if body is not None else None
    )

    escape_pa = 0.0
    if has_escape:
        if not np.isfinite(co2_forcing.escape_rate_kg_s) or co2_forcing.escape_rate_kg_s < 0:
            raise ValueError("escape_rate_kg_s must be finite and >= 0")
        escape_pa = (
            co2_forcing.escape_rate_kg_s
            * body.gravity_m_s2
            / body.surface_area_m2
            * dt_seconds
        )

    def total_pressure_integral(state):
        ps_nd = jnp.exp(grid.to_nodal(state.dynamics.log_surface_pressure))[0]
        return jnp.sum((ps_nd + state.co2_ice[0] + cloud_pressure_equivalent(state, coords)[0]) * weights)

    def step(state):
        external_mass = jnp.asarray(
            0.0 if external_co2_mass_change_kg is None
            else external_co2_mass_change_kg(state, dt_seconds)
        )
        if external_mass.ndim != 0:
            raise ValueError("external_co2_mass_change_kg must return a scalar global mass")
        target_total = total_pressure_integral(state)
        if external_co2_mass_change_kg is not None:
            target_total = target_total + external_mass / mass_per_integral
        target_total = target_total - escape_pa / pressure_scale * weight_sum
        raw = step_fn(state)
        projected = project_co2_reservoirs(raw, coords, specs)
        frost_repaired = projected
        if co2_forcing is not None and co2_forcing.atmospheric_condensation:
            if body is None or dt_seconds is None or not np.isfinite(dt_seconds) or dt_seconds <= 0:
                raise ValueError("body and positive dt_seconds are required for cloud settling")
            projected = jax.lax.cond(
                jnp.any(cloud_pressure_equivalent(projected, coords) > 0.),
                lambda s: settle_co2_clouds(s, coords, specs, body, co2_forcing, dt_seconds),
                lambda s: s, projected)

        ps_nd = jnp.exp(grid.to_nodal(projected.dynamics.log_surface_pressure))
        ice_integral = jnp.sum(projected.co2_ice[0] * weights)
        atmosphere_integral = jnp.sum(ps_nd[0] * weights)
        cloud_integral = jnp.sum(cloud_pressure_equivalent(projected, coords)[0] * weights)
        target_atmosphere = target_total - ice_integral - cloud_integral
        valid = (
            jnp.isfinite(target_atmosphere) & (target_atmosphere > 0.0)
            & jnp.isfinite(atmosphere_integral) & (atmosphere_integral > 0.0)
            & jnp.isfinite(external_mass)
        )
        pressure_factor = jnp.where(valid, target_atmosphere / atmosphere_integral, jnp.nan)
        # A global pressure factor is a spatially constant addition to log(p).
        # Do not round-trip the entire log-pressure field through another
        # nodal->modal transform: that perturbs its spatial pattern and adds
        # avoidable inventory error, particularly across CPU backends.
        log_factor = jnp.where(
            valid,
            jnp.log1p((target_atmosphere - atmosphere_integral) / atmosphere_integral),
            jnp.nan,
        )
        corrected = dataclasses.replace(
            projected.dynamics,
            log_surface_pressure=(
                projected.dynamics.log_surface_pressure + log_factor * uniform_log_pressure
            ),
        )
        from src.framework.physics.co2_clouds import CO2_CLOUD_TRACER
        if CO2_CLOUD_TRACER in corrected.tracers:
            corrected = dataclasses.replace(corrected, tracers={**corrected.tracers,
                CO2_CLOUD_TRACER: corrected.tracers[CO2_CLOUD_TRACER] / pressure_factor})
        final = projected._replace(dynamics=corrected)
        if not return_diagnostics:
            return final
        negative_frost_integral = jnp.sum(jnp.maximum(-raw.co2_ice[0], 0.0) * weights)
        budgets = ([co2_exchange_budgets(s, coords, specs, body, co2_forcing)
                    for s in (raw, frost_repaired, projected, final)]
                   if co2_forcing is not None else [(None, None)] * 4)
        diagnostics = CO2ProjectionDiagnostics(
            raw_total_mass_kg=total_pressure_integral(raw) * mass_per_integral,
            target_total_mass_kg=target_total * mass_per_integral,
            corrected_total_mass_kg=total_pressure_integral(final) * mass_per_integral,
            external_co2_mass_change_kg=external_mass,
            escape_mass_kg=escape_pa / pressure_scale * weight_sum * mass_per_integral,
            negative_frost_repair_kg=negative_frost_integral * mass_per_integral,
            atmospheric_rescale_kg=(target_atmosphere - atmosphere_integral) * mass_per_integral,
            pressure_factor=pressure_factor,
            valid_inventory=valid,
            raw_exchange_energy_j=budgets[0][0],
            frost_repaired_exchange_energy_j=budgets[1][0],
            settled_exchange_energy_j=budgets[2][0],
            corrected_exchange_energy_j=budgets[3][0],
            raw_axial_angular_momentum_kg_m2_s=budgets[0][1],
            frost_repaired_axial_angular_momentum_kg_m2_s=budgets[1][1],
            settled_axial_angular_momentum_kg_m2_s=budgets[2][1],
            corrected_axial_angular_momentum_kg_m2_s=budgets[3][1],
        )
        return final, diagnostics

    return step


def initial_co2_state(dyn_state, coords, ice_pa: float = 0.0, specs=None, body=None,
                      surface_temperature_k: float | None = None, forcing=None):
    """Pair a dynamical ``State`` with an initial (uniform) CO2 frost field.

    ``ice_pa`` is the starting frost everywhere in Pa-equivalent (0 by default, i.e.
    frost forms from the atmosphere as poles cool). Returns the ``(dyn, ice)`` tuple
    the CO2 ODE integrates.
    """
    if body is None and (specs is None or surface_temperature_k is None):
        raise ValueError(
            "generic initial_co2_state requires body when specs or "
            "surface_temperature_k is omitted"
        )
    if specs is None:
        specs = physics_specs(body)
    if surface_temperature_k is None:
        surface_temperature_k = body.reference_temperature_k
    return initial_column_state(
        dyn_state, coords, surface_temperature_k, specs, ice_pa=ice_pa,
        forcing=forcing,
    )
